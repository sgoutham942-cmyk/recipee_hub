
// Function to extract ingredients and measures from a recipe
export const getIngredients = (recipe: any) => {
  if (!recipe) return [];
  
  const ingredients = [];
  for (let i = 1; i <= 20; i++) {
    const ingredient = recipe[`strIngredient${i}` as keyof typeof recipe];
    const measure = recipe[`strMeasure${i}` as keyof typeof recipe];
    
    if (ingredient && ingredient.trim() !== "") {
      ingredients.push({
        name: ingredient,
        measure: measure || ""
      });
    }
  }
  
  return ingredients;
};

// Function to check if a recipe is in favorites
export const checkIsFavorite = (recipeId: string): boolean => {
  const savedFavorites = localStorage.getItem('favoriteRecipes');
  if (savedFavorites && recipeId) {
    const favorites = JSON.parse(savedFavorites);
    return favorites.some((fav: any) => fav.idMeal === recipeId);
  }
  return false;
};

// Function to toggle a recipe in favorites
export const toggleRecipeFavorite = (recipe: any, isFavorite: boolean, setIsFavorite: (value: boolean) => void) => {
  if (!recipe) return;

  // Get current favorites from localStorage
  const savedFavorites = localStorage.getItem('favoriteRecipes');
  let favorites = savedFavorites ? JSON.parse(savedFavorites) : [];
  
  if (isFavorite) {
    // Remove from favorites
    favorites = favorites.filter((fav: any) => fav.idMeal !== recipe.idMeal);
  } else {
    // Add to favorites
    const recipeToSave = {
      idMeal: recipe.idMeal,
      strMeal: recipe.strMeal,
      strMealThumb: recipe.strMealThumb,
      strCategory: recipe.strCategory
    };
    favorites.push(recipeToSave);
  }
  
  // Save back to localStorage
  localStorage.setItem('favoriteRecipes', JSON.stringify(favorites));
  setIsFavorite(!isFavorite);
  
  return favorites;
};
