import { Search, Filter, Bookmark, Clock, Sparkles, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { mealApi } from "@/services/mealApi";

interface RecentlyViewedRecipe {
  idMeal: string;
  strMeal: string;
  strMealThumb: string;
  viewedAt: number;
}

export const Hero = () => {
  const [recentlyViewed, setRecentlyViewed] = useState<RecentlyViewedRecipe[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const loadRecentlyViewed = () => {
      const saved = localStorage.getItem('recentlyViewedRecipes');
      if (saved) {
        const parsed: RecentlyViewedRecipe[] = JSON.parse(saved);
        const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
        const filtered = parsed.filter(recipe => recipe.viewedAt > fiveMinutesAgo);
        setRecentlyViewed(filtered);

        if (filtered.length !== parsed.length) {
          localStorage.setItem('recentlyViewedRecipes', JSON.stringify(filtered));
        }
      }
    };

    loadRecentlyViewed();

    const interval = setInterval(() => {
      loadRecentlyViewed();
    }, 60 * 1000);

    return () => clearInterval(interval);
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchTerm.trim()) {
      toast({
        title: "Please enter a search term",
        description: "Type something to search for recipes",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    setIsSearching(true);
    
    try {
      const results = await mealApi.searchMeals(searchTerm);
      setSearchResults(results || []);
      
      if (!results || results.length === 0) {
        toast({
          title: "No recipes found",
          description: `We couldn't find any recipes for "${searchTerm}". Try a different search.`,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Search error:", error);
      toast({
        title: "Search failed",
        description: "There was an error searching for recipes. Please try again.",
        variant: "destructive"
      });
      setSearchResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearSearch = () => {
    setSearchTerm("");
    setIsSearching(false);
    setSearchResults([]);
  };

  return <div className="relative min-h-[600px] flex flex-col">
      <div className="relative min-h-[600px] flex items-center justify-center bg-gray-900">
        <div className="absolute inset-0 bg-cover bg-center" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1495461199391-8c39ab674295?q=80&w=2940&auto=format&fit=crop")',
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(0,0,0,0.6)'
      }} />
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-up">
            Discover & Cook Amazing Recipes
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto animate-fade-up" style={{
          animationDelay: '0.2s'
        }}>
            Explore thousands of delicious recipes from around the world. Cook like a pro with our step-by-step guides.
          </p>
          
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto animate-fade-up" style={{
          animationDelay: '0.4s'
        }}>
            <div className="flex-1 relative">
              <Input 
                type="text" 
                placeholder="Search for recipes..." 
                className="w-full h-12 pl-12 pr-4 rounded-lg bg-white/90 backdrop-blur-sm" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            </div>
            
            <div className="flex gap-2">
              <Button type="submit" className="h-12 px-6 bg-primary hover:bg-primary/90" disabled={isLoading}>
                {isLoading ? "Searching..." : "Search"}
              </Button>
              {isSearching && (
                <Button 
                  type="button" 
                  variant="outline" 
                  className="h-12 px-4" 
                  onClick={clearSearch}
                >
                  Clear
                </Button>
              )}
            </div>
          </form>

          <div className="mt-8 flex justify-center gap-4 animate-fade-up" style={{
          animationDelay: '0.6s'
        }}>
            <Link to="/add-recipe">
              <Button className="bg-green-500 hover:bg-green-600">
                Add New Recipe
              </Button>
            </Link>
            <Link to="/favorites">
              <Button variant="outline" className="gap-2 border-white text-gray-950 bg-zinc-50">
                <Bookmark className="h-5 w-5" />
                My Favorites
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {isSearching && (
        <div className="relative py-16 bg-gray-900/90">
          <div className="absolute inset-0 bg-cover bg-center -z-10" style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1556910103-1c02745adc6b?q=80&w=2940&auto=format&fit=crop")',
            backgroundBlendMode: 'multiply',
            backgroundColor: 'rgba(0,0,0,0.85)'
          }} />
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-white flex items-center gap-2">
                Search Results for "{searchTerm}"
                <span className="inline-block">
                  <Sparkles className="h-5 w-5 text-primary" />
                </span>
              </h2>
              <Button variant="outline" onClick={clearSearch}>Back to Home</Button>
            </div>
            
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(8)].map((_, index) => (
                  <Card key={index} className="overflow-hidden bg-gray-800/50 border-gray-700 h-full">
                    <div className="aspect-video bg-gray-700 animate-pulse"></div>
                    <div className="p-4 space-y-2">
                      <div className="h-6 bg-gray-700 rounded animate-pulse"></div>
                      <div className="h-4 w-1/2 bg-gray-700 rounded animate-pulse"></div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : searchResults.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-2xl text-white mb-4">No recipes found</h3>
                <p className="text-gray-300 mb-6">Try searching with different keywords</p>
                <Button onClick={clearSearch}>Back to Home</Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {searchResults.map(recipe => (
                  <Link to={`/recipe/${recipe.idMeal}`} key={recipe.idMeal} className="group">
                    <Card className="overflow-hidden bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 h-full relative">
                      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-700">
                        <div className="absolute inset-[-100%] w-[300%] h-[200%] bg-gradient-to-r from-transparent via-white/5 to-transparent transform -rotate-45 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1500"></div>
                      </div>
                      
                      <div className="aspect-video relative">
                        <img 
                          src={recipe.strMealThumb} 
                          alt={recipe.strMeal} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-medium text-white truncate group-hover:text-primary transition-colors">
                          {recipe.strMeal}
                        </h3>
                        <p className="text-sm text-gray-300 mt-1">
                          {recipe.strCategory && `Category: ${recipe.strCategory}`}
                          {recipe.strArea && recipe.strCategory && " · "}
                          {recipe.strArea && `${recipe.strArea} Cuisine`}
                        </p>
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {recentlyViewed.length > 0 && !isSearching && <div className="relative py-16 bg-gray-900/90 overflow-hidden">
          <div className="absolute inset-0 -z-5 opacity-20">
            {[...Array(20)].map((_, i) => (
              <div 
                key={i}
                className="absolute animate-float"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  transform: `scale(${0.5 + Math.random()})`,
                  animationDelay: `${Math.random() * 5}s`,
                  animationDuration: `${10 + Math.random() * 15}s`
                }}
              >
                {i % 3 === 0 ? (
                  <Sparkles className="text-primary/40 w-8 h-8" />
                ) : i % 3 === 1 ? (
                  <Star className="text-yellow-500/30 w-6 h-6" />
                ) : (
                  <div className="w-3 h-3 rounded-full bg-gradient-to-r from-primary/40 to-yellow-500/30 blur-sm" />
                )}
              </div>
            ))}
          </div>
          
          <div className="absolute inset-0 -z-5">
            <div className="absolute top-0 left-1/4 w-[30%] h-[500px] bg-gradient-to-b from-primary/10 to-transparent blur-3xl transform -rotate-12 opacity-30"></div>
            <div className="absolute top-0 right-1/4 w-[25%] h-[400px] bg-gradient-to-b from-yellow-500/10 to-transparent blur-3xl transform rotate-12 opacity-20"></div>
          </div>
          
          <div className="absolute inset-0 bg-cover bg-center -z-10" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1556910103-1c02745adc6b?q=80&w=2940&auto=format&fit=crop")',
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(0,0,0,0.85)'
      }} />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-white flex items-center gap-2">
                Recently Viewed
                <span className="inline-block animate-pulse-slow">
                  <Sparkles className="h-5 w-5 text-primary" />
                </span>
              </h2>
              <div className="flex items-center text-gray-300">
                <Clock className="mr-2 h-5 w-5" />
                <span>Auto-clears after 5 minutes</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {recentlyViewed.map(recipe => <Link to={`/recipe/${recipe.idMeal}`} key={recipe.idMeal} className="group">
                  <Card className="overflow-hidden bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 h-full relative">
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-700">
                      <div className="absolute inset-[-100%] w-[300%] h-[200%] bg-gradient-to-r from-transparent via-white/5 to-transparent transform -rotate-45 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1500"></div>
                    </div>
                    
                    <div className="aspect-video relative">
                      <img src={recipe.strMealThumb} alt={recipe.strMeal} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                      <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full flex items-center">
                        <Clock className="mr-1 h-3 w-3" />
                        {Math.floor((Date.now() - recipe.viewedAt) / 60000)} min ago
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="text-lg font-medium text-white truncate group-hover:text-primary transition-colors">
                        {recipe.strMeal}
                      </h3>
                    </div>
                  </Card>
                </Link>)}
            </div>
          </div>
        </div>}
    </div>;
};
