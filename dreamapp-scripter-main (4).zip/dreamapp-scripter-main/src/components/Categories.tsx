
import { Egg, CookingPot, Utensils, CakeSlice, ArrowRight, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";

export const Categories = () => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  
  const categories = [
    { icon: <Egg className="w-8 h-8" />, name: "Breakfast", count: "124 recipes" },
    { icon: <CookingPot className="w-8 h-8" />, name: "Lunch", count: "246 recipes" },
    { icon: <Utensils className="w-8 h-8" />, name: "Dinner", count: "357 recipes" },
    { icon: <CakeSlice className="w-8 h-8" />, name: "Desserts", count: "189 recipes" },
  ];

  return (
    <section className="py-16 bg-gray-900 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div 
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${8 + Math.random() * 10}s`
            }}
          >
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
        ))}
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-3xl font-bold text-white flex items-center">
            Recipe Categories
            <span className="inline-block ml-2 animate-pulse">
              <Sparkles className="w-5 h-5 text-primary" />
            </span>
          </h2>
          <Link to="/categories" className="text-primary hover:text-primary/90 flex items-center gap-2 relative group">
            <span>View All Categories</span> 
            <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            <span className="absolute inset-0 bg-primary/10 scale-0 rounded-lg group-hover:scale-100 transition-transform duration-300 -z-10"></span>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <Link
              key={category.name}
              to={`/category/${category.name.toLowerCase()}`}
              className="group p-6 bg-gray-800/50 backdrop-blur-sm rounded-lg hover:bg-gray-800/70 transition-all duration-300 relative overflow-hidden"
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              {/* Magic effect when hovered */}
              {hoveredIndex === index && (
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent animate-pulse-slow pointer-events-none" />
              )}
              
              <div className="flex flex-col items-center text-center space-y-4 relative z-10">
                <div className="p-4 rounded-full bg-primary/10 text-primary group-hover:scale-110 transition-transform duration-300 relative">
                  {category.icon}
                  
                  {/* Animated border effect */}
                  <div className="absolute inset-0 rounded-full border border-primary/50 scale-0 group-hover:scale-110 opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
                  <div className="absolute inset-0 rounded-full border border-primary/30 scale-0 group-hover:scale-125 opacity-0 group-hover:opacity-100 transition-all duration-1000 delay-100"></div>
                </div>
                
                <h3 className="text-xl font-semibold text-white group-hover:text-primary transition-colors duration-300">{category.name}</h3>
                <p className="text-gray-400 group-hover:text-gray-300 transition-colors duration-300">{category.count}</p>
                
                {/* Appear on hover */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-primary/20 to-transparent h-0 group-hover:h-12 transition-all duration-300 -z-10"></div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Add animation styles */}
      <style>
        {`
        @keyframes float {
          0% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(10deg); }
          100% { transform: translateY(0) rotate(0deg); }
        }
        .animate-float {
          animation: float 10s ease-in-out infinite;
        }
        .animate-pulse-slow {
          animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 0.8; }
        }
        `}
      </style>
    </section>
  );
};
