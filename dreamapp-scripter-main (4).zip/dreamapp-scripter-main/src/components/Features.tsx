
import { ChefHat, PlayCircle, BookMarked, Search, Trophy, Lock, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export const Features = () => {
  const navigate = useNavigate();
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  
  const features = [{
    icon: <ChefHat className="w-12 h-12" />,
    title: "Expert Recipes",
    description: "Curated by Professional Chefs & Food Experts",
    benefits: ["Get expert-crafted recipes", "Learn professional techniques", "Discover unique flavors"]
  }, {
    icon: <PlayCircle className="w-12 h-12" />,
    title: "Step by Step",
    description: "Easy-to-Follow Recipe Videos & Guides",
    benefits: ["Watch detailed recipe videos", "Follow clear instructions", "Master new cooking skills"]
  }, {
    icon: <BookMarked className="w-12 h-12" />,
    title: "Save Favorites",
    description: "Build Your Personal Cookbook",
    benefits: ["Save recipes with one click", "Organize your collection", "Access anywhere"]
  }, {
    icon: <Search className="w-12 h-12" />,
    title: "Smart Search",
    description: "Find Any Recipe Instantly!",
    benefits: ["Type in any dish name for results", "Filter by ingredients", "Search by cuisine"]
  }];
  const subscriptionAdvantages = [{
    icon: <Trophy className="w-12 h-12" />,
    title: "Premium Recipes",
    description: "Exclusive recipes from world-renowned chefs",
    imageUrl: "https://images.unsplash.com/photo-1547592180-85f173990554?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  }, {
    icon: <Lock className="w-12 h-12" />,
    title: "Ad-Free Experience",
    description: "Enjoy an uninterrupted cooking experience",
    imageUrl: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  }, {
    icon: <Sparkles className="w-12 h-12" />,
    title: "Meal Planning Tools",
    description: "Plan your meals for the week with smart tools",
    imageUrl: "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  }];
  const handleSubscriptionClick = () => {
    navigate('/subscription');
  };
  return <section className="py-16 bg-black relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none">
        {[...Array(12)].map((_, i) => (
          <div 
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${8 + Math.random() * 10}s`
            }}
          >
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
        ))}
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <h2 className="text-3xl font-bold text-white text-center mb-12 flex items-center justify-center">
          Why Choose Recipe Hub?
          <span className="inline-block ml-2 animate-pulse">
            <Sparkles className="w-5 h-5 text-primary" />
          </span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={feature.title} 
              className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm hover:bg-gray-800/70 transition-all duration-300 relative overflow-hidden"
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              {/* Magic effect when hovered */}
              {hoveredIndex === index && (
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent animate-pulse-slow pointer-events-none" />
              )}
              
              <div className="flex flex-col items-center text-center space-y-4 relative z-10">
                <div className="p-4 rounded-full bg-primary/10 text-primary group-hover:scale-110 transition-transform duration-300 relative">
                  {feature.icon}
                  
                  {/* Animated border effect */}
                  <div className="absolute inset-0 rounded-full border border-primary/50 scale-0 hover:scale-110 opacity-0 hover:opacity-100 transition-all duration-700"></div>
                  <div className="absolute inset-0 rounded-full border border-primary/30 scale-0 hover:scale-125 opacity-0 hover:opacity-100 transition-all duration-1000 delay-100"></div>
                </div>
                
                <h3 className="text-xl font-semibold text-white hover:text-primary transition-colors duration-300">{feature.title}</h3>
                <p className="text-gray-400 hover:text-gray-300 transition-colors duration-300">{feature.description}</p>
                
                <ul className="text-gray-400 text-sm space-y-2">
                  {feature.benefits.map(benefit => <li key={benefit} className="flex items-center justify-center gap-2">
                      <span className="text-primary">•</span> {benefit}
                    </li>)}
                </ul>
                
                {/* Appear on hover */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-primary/20 to-transparent h-0 hover:h-12 transition-all duration-300 -z-10"></div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20">
          <h2 className="text-3xl font-bold text-white text-center mb-6 flex items-center justify-center">
            Upgrade Your Cooking Experience
            <span className="inline-block ml-2 animate-pulse">
              <Sparkles className="w-5 h-5 text-primary" />
            </span>
          </h2>
          <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
            Subscribe to unlock premium features and take your culinary skills to the next level
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {subscriptionAdvantages.map((advantage, index) => (
              <div 
                key={advantage.title} 
                className="relative overflow-hidden rounded-xl group cursor-pointer" 
                onClick={handleSubscriptionClick}
                onMouseEnter={() => setHoveredIndex(index + features.length)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <img src={advantage.imageUrl} alt={advantage.title} className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6">
                  {hoveredIndex === index + features.length && (
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent animate-pulse-slow pointer-events-none" />
                  )}
                  <div className="text-primary mb-2 relative">
                    {advantage.icon}
                    <div className="absolute inset-0 rounded-full border border-primary/50 scale-0 group-hover:scale-110 opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-1 group-hover:text-primary transition-colors duration-300">{advantage.title}</h3>
                  <p className="text-gray-300 text-sm group-hover:text-white transition-colors duration-300">{advantage.description}</p>
                  <Button variant="outline" size="sm" className="mt-3 border-white/30 hover:text-white bg-zinc-600 hover:bg-zinc-500 relative overflow-hidden group">
                    <span className="relative z-10">Unlock Now</span>
                    <span className="absolute inset-0 bg-primary/20 transform scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-300"></span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex justify-center mt-10">
            <Button variant="default" size="lg" className="bg-primary hover:bg-primary/90 relative overflow-hidden group" onClick={handleSubscriptionClick}>
              <span className="relative z-10">Subscribe Now</span>
              <span className="absolute inset-0 bg-white/10 transform scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-300"></span>
            </Button>
          </div>
        </div>
      </div>
    </section>;
};
