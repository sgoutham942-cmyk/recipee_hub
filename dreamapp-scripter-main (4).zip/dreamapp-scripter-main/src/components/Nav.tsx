
import { Heart, Menu, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

export const Nav = () => {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [favoriteCount, setFavoriteCount] = useState(0);
  const { toast } = useToast();
  
  // Check if user is subscribed and logged in
  useEffect(() => {
    const checkSubscription = () => {
      const subscriptionStatus = localStorage.getItem("isSubscribed");
      setIsSubscribed(subscriptionStatus === "true");
    };
    
    const checkLoginStatus = () => {
      // Check if user is logged in
      const loginStatus = localStorage.getItem("isLoggedIn");
      setIsLoggedIn(loginStatus === "true");
    };
    
    const checkFavoriteCount = () => {
      const savedFavorites = localStorage.getItem('favoriteRecipes');
      if (savedFavorites) {
        const favorites = JSON.parse(savedFavorites);
        setFavoriteCount(favorites.length);
      }
    };
    
    // Check on initial load
    checkSubscription();
    checkLoginStatus();
    checkFavoriteCount();
    
    // Listen for changes in subscription and login status
    const handleStorageEvent = () => {
      checkSubscription();
      checkLoginStatus();
      checkFavoriteCount();
    };
    
    window.addEventListener("storage", handleStorageEvent);
    
    // Set up interval to periodically check subscription status
    const interval = setInterval(() => {
      checkSubscription();
      checkLoginStatus();
      checkFavoriteCount();
    }, 5000); // Check every 5 seconds
    
    return () => {
      window.removeEventListener("storage", handleStorageEvent);
      clearInterval(interval);
    };
  }, []);

  const handleFavoritesClick = () => {
    if (!isLoggedIn) {
      toast({
        title: "Sign in required",
        description: "Please sign in to view your favorites",
        variant: "destructive",
      });
    } else {
      // Navigate to favorites page
      window.location.href = "/favorites";
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <span className="text-primary text-xl font-bold">RecipeHub</span>
            </a>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="/recipes" className="text-gray-700 hover:text-primary transition-colors">
              Recipes
            </a>
            <a href="/categories" className="text-gray-700 hover:text-primary transition-colors">
              Categories
            </a>
            <a href="/about" className="text-gray-700 hover:text-primary transition-colors">
              About
            </a>
            <a href="/contact" className="text-gray-700 hover:text-primary transition-colors">
              Contact
            </a>
          </div>

          <div className="flex items-center space-x-4">
            {isLoggedIn && isSubscribed && (
              <div className="flex items-center text-green-600 text-sm font-medium">
                <ShieldCheck className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">Premium</span>
              </div>
            )}
            <button 
              className="relative p-2 hover:text-primary transition-colors hover-tilt group"
              onClick={handleFavoritesClick}
              aria-label="Your favorites"
            >
              <Heart className={`h-5 w-5 ${isLoggedIn ? 'group-hover:fill-red-100' : ''} hover-jello`} />
              {isLoggedIn && favoriteCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-4 w-4 flex items-center justify-center animate-bounce-in">
                  {favoriteCount}
                </span>
              )}
              <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap">
                {isLoggedIn ? "Your Favorites" : "Sign in to save favorites"}
              </div>
            </button>
            {!isLoggedIn ? (
              <Link to="/auth">
                <Button variant="default" className="bg-primary hover:bg-primary/90">
                  Sign In
                </Button>
              </Link>
            ) : (
              <Button 
                variant="outline" 
                className="bg-transparent border-gray-300 text-gray-700"
                onClick={() => {
                  localStorage.removeItem("isLoggedIn");
                  window.dispatchEvent(new Event('storage'));
                }}
              >
                Sign Out
              </Button>
            )}
            {!isLoggedIn && !isSubscribed && (
              <Link to="/subscription">
                <Button variant="outline" className="hidden sm:inline-flex">
                  Subscribe
                </Button>
              </Link>
            )}
            <button className="md:hidden p-2">
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};
