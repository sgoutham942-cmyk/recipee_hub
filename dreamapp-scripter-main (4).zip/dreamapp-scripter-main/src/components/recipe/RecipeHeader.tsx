
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { BackButton } from "@/components/BackButton";
import { Button } from "@/components/ui/button";
import { Heart, Bookmark } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface RecipeHeaderProps {
  recipe: any;
  id: string;
}

export const RecipeHeader = ({ recipe, id }: RecipeHeaderProps) => {
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    // Check if this recipe is in favorites
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    if (savedFavorites && id) {
      const favorites = JSON.parse(savedFavorites);
      const isInFavorites = favorites.some((fav: any) => fav.idMeal === id);
      setIsFavorite(isInFavorites);
    }
  }, [id]);

  const toggleFavorite = () => {
    if (!recipe) return;

    // Get current favorites from localStorage
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    let favorites = savedFavorites ? JSON.parse(savedFavorites) : [];
    
    if (isFavorite) {
      // Remove from favorites
      favorites = favorites.filter((fav: any) => fav.idMeal !== recipe.idMeal);
      toast({
        title: "Removed from favorites",
        description: `${recipe.strMeal} has been removed from your favorites`,
      });
    } else {
      // Add to favorites
      const recipeToSave = {
        idMeal: recipe.idMeal,
        strMeal: recipe.strMeal,
        strMealThumb: recipe.strMealThumb,
        strCategory: recipe.strCategory
      };
      favorites.push(recipeToSave);
      toast({
        title: "Added to favorites",
        description: `${recipe.strMeal} has been added to your favorites`,
      });
    }
    
    // Save back to localStorage
    localStorage.setItem('favoriteRecipes', JSON.stringify(favorites));
    setIsFavorite(!isFavorite);
  };

  return (
    <div className="flex items-center gap-4 mb-8 animate-fade-up">
      <BackButton />
      <h1 className="text-4xl font-bold text-white">Recipe Details</h1>
      <div className="flex-grow"></div>
      <Link to="/favorites">
        <Button variant="outline" className="gap-2 hover-lift button-pop-effect">
          <Bookmark className="h-5 w-5 hover-jello" />
          <span className="hidden sm:inline">My Favorites</span>
        </Button>
      </Link>
    </div>
  );
};
