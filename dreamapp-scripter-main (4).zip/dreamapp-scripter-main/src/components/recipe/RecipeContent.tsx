
interface Ingredient {
  name: string;
  measure: string;
}

interface RecipeContentProps {
  ingredients: Ingredient[];
  instructions: string[];
}

export const RecipeContent = ({ ingredients, instructions }: RecipeContentProps) => {
  return (
    <div className="p-6 border-t border-gray-700">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div>
          <h3 className="text-xl font-bold text-white mb-4">Ingredients</h3>
          <ul className="space-y-2">
            {ingredients.map((item, index) => (
              <li key={index} className="flex items-baseline gap-2 text-gray-300">
                <span className="inline-block w-2 h-2 bg-primary rounded-full mt-1"></span>
                <span className="font-medium">{item.measure}</span>
                <span>{item.name}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-xl font-bold text-white mb-4">Instructions</h3>
          <div className="text-gray-300">
            {instructions.map((paragraph, index) => (
              <p key={index} className="mb-4">{paragraph}</p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
