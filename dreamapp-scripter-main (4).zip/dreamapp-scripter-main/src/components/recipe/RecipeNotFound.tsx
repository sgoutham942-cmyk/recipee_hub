
import { BackButton } from "@/components/BackButton";

export const RecipeNotFound = () => {
  return (
    <div className="text-center py-8">
      <h2 className="text-2xl font-semibold text-white mb-2">Recipe not found</h2>
      <p className="text-gray-300 mb-4">The recipe you're looking for doesn't exist or was removed</p>
      <BackButton />
    </div>
  );
};
