
import { Heart, Crown, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface RecipeImageSectionProps {
  recipe: any;
  isFavorite: boolean;
  toggleFavorite: () => void;
}

export const RecipeImageSection = ({ recipe, isFavorite, toggleFavorite }: RecipeImageSectionProps) => {
  const navigate = useNavigate();
  
  // For demo purposes, we'll consider some recipes as premium
  const isPremium = recipe.idMeal && parseInt(recipe.idMeal.toString().slice(-1)) % 3 === 0;
  
  return (
    <div className="md:w-1/2 relative card-3d">
      <img 
        src={recipe.strMealThumb} 
        alt={recipe.strMeal}
        className="w-full h-full object-cover max-h-[500px] hover-shadow transition-transform duration-300 hover:scale-105 rounded-lg"
      />
      
      {isPremium && (
        <div className="absolute top-4 right-4 flex items-center gap-1 bg-gradient-to-r from-amber-500 to-yellow-500 text-white py-1 px-3 rounded-full shadow-lg animate-float hover-glow">
          <Crown className="h-4 w-4 animate-glow" />
          <span className="text-sm font-medium">Premium Recipe</span>
        </div>
      )}
      
      {isPremium && (
        <div 
          className="absolute bottom-4 right-4 cursor-pointer"
          onClick={() => navigate('/subscription')}
        >
          <Button size="sm" className="bg-gradient-to-r from-amber-500 to-yellow-500 border-none hover:from-amber-600 hover:to-yellow-600 button-pop-effect animate-shadow-pulse hover-jello">
            <Star className="mr-1 h-4 w-4 animate-glow" /> Unlock Premium
          </Button>
        </div>
      )}
      
      <button 
        onClick={toggleFavorite}
        className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm hover:bg-white p-2 rounded-full shadow-md transition-all duration-300 hover-tilt"
        aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
      >
        <Heart className={`h-5 w-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'} hover-jello`} />
      </button>
    </div>
  );
};
