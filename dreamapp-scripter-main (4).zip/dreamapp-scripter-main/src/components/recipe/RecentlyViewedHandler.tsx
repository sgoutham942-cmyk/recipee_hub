
import { useEffect } from "react";

// Interface for recently viewed recipes
interface RecentlyViewedRecipe {
  idMeal: string;
  strMeal: string;
  strMealThumb: string;
  viewedAt: number;
}

interface RecentlyViewedHandlerProps {
  recipe: any;
}

export const RecentlyViewedHandler = ({ recipe }: RecentlyViewedHandlerProps) => {
  // Add to recently viewed when recipe loads
  useEffect(() => {
    if (recipe && recipe.idMeal) {
      // Get current recently viewed recipes from localStorage
      const savedRecipes = localStorage.getItem('recentlyViewedRecipes');
      let recentlyViewed: RecentlyViewedRecipe[] = savedRecipes ? JSON.parse(savedRecipes) : [];
      
      // Filter out recipes older than 5 minutes and the current one (to avoid duplicates)
      const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
      recentlyViewed = recentlyViewed.filter(
        item => item.viewedAt > fiveMinutesAgo && item.idMeal !== recipe.idMeal
      );
      
      // Add the current recipe
      recentlyViewed.unshift({
        idMeal: recipe.idMeal,
        strMeal: recipe.strMeal,
        strMealThumb: recipe.strMealThumb,
        viewedAt: Date.now()
      });
      
      // Limit to 8 most recent recipes
      if (recentlyViewed.length > 8) {
        recentlyViewed = recentlyViewed.slice(0, 8);
      }
      
      // Save back to localStorage
      localStorage.setItem('recentlyViewedRecipes', JSON.stringify(recentlyViewed));
    }
  }, [recipe]);

  return null;
};
