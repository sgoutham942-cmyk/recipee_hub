
import { Clock, Users, ExternalLink, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";

interface RecipeInfoSectionProps {
  recipe: any;
  isFavorite: boolean;
  toggleFavorite: () => void;
}

export const RecipeInfoSection = ({ recipe, isFavorite, toggleFavorite }: RecipeInfoSectionProps) => {
  return (
    <div className="p-6 md:w-1/2">
      <div className="flex justify-between items-start mb-4">
        <h2 className="text-3xl font-bold text-white">{recipe.strMeal}</h2>
        <Button 
          variant="ghost" 
          size="icon" 
          className={`${isFavorite ? 'text-red-500' : 'text-gray-400'} hover:text-red-400`}
          onClick={toggleFavorite}
        >
          <Heart className="h-6 w-6" fill={isFavorite ? "currentColor" : "none"} />
        </Button>
      </div>
      
      <div className="flex gap-4 items-center mb-6">
        <span className="inline-block px-3 py-1 bg-primary text-white text-sm rounded-full">
          {recipe.strCategory}
        </span>
        {recipe.strArea && (
          <span className="inline-block px-3 py-1 bg-gray-700 text-white text-sm rounded-full">
            {recipe.strArea} Cuisine
          </span>
        )}
      </div>
      
      <div className="flex gap-6 mb-6">
        <div className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-gray-400" />
          <span className="text-white">30 mins</span>
        </div>
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5 text-gray-400" />
          <span className="text-white">4 servings</span>
        </div>
      </div>
      
      {recipe.strTags && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-white mb-2">Tags</h3>
          <div className="flex flex-wrap gap-2">
            {recipe.strTags.split(',').map((tag: string, index: number) => (
              <span key={index} className="px-2 py-1 bg-gray-700 text-sm text-gray-300 rounded">
                {tag.trim()}
              </span>
            ))}
          </div>
        </div>
      )}
      
      {recipe.strSource && (
        <div className="mb-4">
          <a 
            href={recipe.strSource} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-primary hover:underline"
          >
            <ExternalLink className="h-4 w-4" />
            View Original Recipe
          </a>
        </div>
      )}
      
      {recipe.strYoutube && (
        <div className="mb-4">
          <a 
            href={recipe.strYoutube} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-red-500 hover:underline"
          >
            <ExternalLink className="h-4 w-4" />
            Watch Video Tutorial
          </a>
        </div>
      )}
    </div>
  );
};
