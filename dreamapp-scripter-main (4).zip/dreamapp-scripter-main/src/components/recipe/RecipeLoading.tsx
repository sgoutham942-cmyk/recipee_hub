
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export const RecipeLoading = () => {
  return (
    <Card className="bg-gray-800/50 border-gray-700 p-6 animate-fade-in">
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row gap-8">
          <Skeleton className="h-80 w-full md:w-1/2 rounded-lg animate-shimmer bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 bg-[length:400%_100%]" />
          <div className="space-y-4 w-full md:w-1/2">
            <Skeleton className="h-12 w-3/4 animate-pulse" />
            <Skeleton className="h-6 w-1/3 animate-pulse" />
            <Skeleton className="h-24 w-full animate-pulse" />
            <div className="flex gap-4">
              <Skeleton className="h-10 w-24 animate-pulse" />
              <Skeleton className="h-10 w-24 animate-pulse" />
            </div>
          </div>
        </div>
        <Skeleton className="h-6 w-1/4 animate-pulse" />
        <div className="grid grid-cols-2 gap-2">
          {Array(8).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-8 w-full animate-pulse" style={{animationDelay: `${i * 0.1}s`}} />
          ))}
        </div>
        <Skeleton className="h-6 w-1/4 animate-pulse" />
        <Skeleton className="h-64 w-full animate-pulse" />
      </div>
    </Card>
  );
};
