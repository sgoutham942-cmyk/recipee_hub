
import { useState, useEffect } from "react";
import { mealApi } from "@/services/mealApi";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Globe } from "lucide-react";

export const CountryList = () => {
  const [countries, setCountries] = useState<{ strArea: string }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const data = await mealApi.listAllAreas();
        setCountries(data);
      } catch (error) {
        console.error("Failed to fetch countries:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCountries();
  }, []);

  // Country flags - map country names to 2-letter country codes
  const getCountryFlag = (country: string) => {
    const countryCodeMap: Record<string, string> = {
      'American': 'us',
      'British': 'gb',
      'Canadian': 'ca',
      'Chinese': 'cn',
      'Dutch': 'nl',
      'Egyptian': 'eg',
      'French': 'fr',
      'Greek': 'gr',
      'Indian': 'in',
      'Irish': 'ie',
      'Italian': 'it',
      'Jamaican': 'jm',
      'Japanese': 'jp',
      'Kenyan': 'ke',
      'Malaysian': 'my',
      'Mexican': 'mx',
      'Moroccan': 'ma',
      'Polish': 'pl',
      'Portuguese': 'pt',
      'Russian': 'ru',
      'Spanish': 'es',
      'Thai': 'th',
      'Tunisian': 'tn',
      'Turkish': 'tr',
      'Vietnamese': 'vn'
    };

    const code = countryCodeMap[country] || 'unknown';
    if (code === 'unknown') return null;
    return `https://flagcdn.com/48x36/${code}.png`;
  };

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {Array(10).fill(0).map((_, index) => (
          <Skeleton key={index} className="h-32 rounded-lg" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
      {countries.map((country) => (
        <Link key={country.strArea} to={`/country/${country.strArea}`}>
          <Card className="h-full hover:shadow-lg transition-shadow bg-gray-800/50 border-gray-700 group overflow-hidden">
            <CardContent className="flex flex-col items-center justify-center p-4 h-full text-center">
              <div className="mb-3 mt-2 relative w-16 h-16 rounded-full bg-gray-700/50 flex items-center justify-center overflow-hidden">
                {getCountryFlag(country.strArea) ? (
                  <img 
                    src={getCountryFlag(country.strArea)} 
                    alt={`${country.strArea} flag`} 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Globe className="w-8 h-8 text-gray-300" />
                )}
              </div>
              <h3 className="text-lg font-medium text-white group-hover:text-primary transition-colors">
                {country.strArea}
              </h3>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
};
