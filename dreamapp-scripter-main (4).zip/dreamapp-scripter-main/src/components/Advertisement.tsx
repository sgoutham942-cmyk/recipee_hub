
import { useState, useEffect, useRef } from "react";
import { X, Volume2, VolumeX, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { fetchAdsFromApi, type Ad } from "@/services/adService";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";

interface AdvertisementProps {
  isSubscribed?: boolean;
  forceShow?: boolean;
  customAdUrl?: string;
  customAdTitle?: string;
  frequentAds?: boolean;
}

export const Advertisement = ({ 
  isSubscribed = false, 
  forceShow = false,
  customAdUrl, 
  customAdTitle,
  frequentAds = false
}: AdvertisementProps) => {
  const [showAd, setShowAd] = useState(false);
  const [currentAdIndex, setCurrentAdIndex] = useState(0);
  const [canSkip, setCanSkip] = useState(false);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [ads, setAds] = useState<Ad[]>([]);
  const [localSubscriptionStatus, setLocalSubscriptionStatus] = useState(isSubscribed);
  const [progress, setProgress] = useState(0);
  const [adTimeRemaining, setAdTimeRemaining] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Show ad every 3 minutes (180000 ms) for normal users
  // Show ad every 1 minute (60000 ms) for non-logged in users or if frequentAds=true
  const AD_INTERVAL = frequentAds ? 60000 : 180000;
  // Allow skipping after 5 seconds
  const SKIP_DELAY = 5000;

  // Force show ad if requested
  useEffect(() => {
    if (forceShow && !localSubscriptionStatus) {
      setShowAd(true);
    }
  }, [forceShow, localSubscriptionStatus]);

  // Check subscription status changes
  useEffect(() => {
    setLocalSubscriptionStatus(isSubscribed);
    
    // If user just subscribed, hide any showing ads
    if (isSubscribed && showAd) {
      setShowAd(false);
      setCanSkip(false);
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    }
  }, [isSubscribed]);

  // Load ads from API
  useEffect(() => {
    const loadAds = async () => {
      if (customAdUrl && customAdTitle) {
        // Use custom ad if provided
        setAds([{
          id: "custom-ad",
          url: customAdUrl,
          title: customAdTitle,
          duration: 10
        }]);
      } else {
        // Otherwise fetch from API
        try {
          const apiAds = await fetchAdsFromApi();
          if (apiAds && apiAds.length > 0) {
            setAds(apiAds);
          }
        } catch (error) {
          console.error("Error fetching ads:", error);
        }
      }
    };

    loadAds();
  }, [customAdUrl, customAdTitle]);

  useEffect(() => {
    // Don't show ads for subscribed users
    if (localSubscriptionStatus) return;

    // Initial ad after specified interval
    const initialTimer = setTimeout(() => {
      setShowAd(true);
    }, forceShow ? 0 : AD_INTERVAL);

    return () => {
      clearTimeout(initialTimer);
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    };
  }, [localSubscriptionStatus, AD_INTERVAL, forceShow]);

  useEffect(() => {
    if (showAd) {
      // Reset states
      setIsVideoLoaded(false);
      setIsVideoPlaying(false);
      setProgress(0);
      setCanSkip(false);
      
      if (ads.length > 0) {
        const currentAd = ads[currentAdIndex] || ads[0];
        setAdTimeRemaining(currentAd.duration);
        
        // Allow skipping after SKIP_DELAY
        const skipTimer = setTimeout(() => {
          setCanSkip(true);
        }, SKIP_DELAY);

        // Set up progress tracking
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current);
        }
        
        progressIntervalRef.current = setInterval(() => {
          setAdTimeRemaining(prev => {
            if (prev <= 1) {
              // Ad is finished
              handleAdComplete();
              return 0;
            }
            // Update progress bar
            setProgress((currentAd.duration - (prev - 1)) / currentAd.duration * 100);
            return prev - 1;
          });
        }, 1000);

        // Set up next ad timer
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => {
          setShowAd(true);
          // Rotate through available ads
          setCurrentAdIndex((prev) => (prev + 1) % ads.length);
        }, AD_INTERVAL);

        return () => {
          clearTimeout(skipTimer);
          if (progressIntervalRef.current) {
            clearInterval(progressIntervalRef.current);
          }
        };
      }
    }
  }, [showAd, ads, currentAdIndex, AD_INTERVAL]);

  const handleSkip = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
    }
    setShowAd(false);
    setCanSkip(false);
    toast({
      title: "Ad skipped",
      description: "You can subscribe to remove ads completely",
      variant: "default",
    });
  };

  const handleAdComplete = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
    }
    setShowAd(false);
    setCanSkip(false);
  };

  const handleVideoLoaded = () => {
    setIsVideoLoaded(true);
    
    // Try to play the video
    if (videoRef.current) {
      const playPromise = videoRef.current.play();
      
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsVideoPlaying(true);
            
            // Also play the audio if available
            if (audioRef.current && !isMuted) {
              audioRef.current.play().catch(error => {
                console.error("Error playing audio:", error);
                setIsMuted(true);
              });
            }
          })
          .catch(error => {
            console.error("Error playing video:", error);
            // Try playing muted if autoplay with sound fails
            if (videoRef.current) {
              videoRef.current.muted = true;
              videoRef.current.play()
                .then(() => {
                  setIsVideoPlaying(true);
                  setIsMuted(true);
                })
                .catch(err => {
                  console.error("Failed to play even muted:", err);
                });
            }
          });
      }
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
    }
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
    }
  };

  const handleAdClick = () => {
    // In a real ad implementation, this would track the click and redirect
    // to the advertiser's website
    toast({
      title: "Ad clicked",
      description: "In a real app, this would open the advertiser's website",
      variant: "default",
    });
    
    // Open YouTube video in new tab if it's a YouTube ad
    const currentAd = ads[currentAdIndex] || ads[0];
    if (currentAd?.isYoutubeVideo) {
      window.open(currentAd.url, '_blank');
    }
  };

  if (!showAd || localSubscriptionStatus) return null;

  // Get current ad, fallback to first ad if index is out of bounds
  const currentAd = ads[currentAdIndex] || ads[0];
  if (!currentAd) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 animate-fade-in">
      <div className="relative w-full max-w-3xl bg-black rounded-lg overflow-hidden shadow-2xl card-3d">
        {/* Progress bar */}
        <Progress value={progress} className="h-1 absolute top-0 left-0 right-0 z-10" />
        
        {/* Ad Content */}
        <div className="relative cursor-pointer" onClick={handleAdClick}>
          {!isVideoLoaded && (
            <div className="absolute inset-0 flex items-center justify-center bg-black">
              <Skeleton className="h-72 w-full animate-pulse" />
              <div className="absolute animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          )}
          
          {/* Handle YouTube videos differently */}
          {currentAd.isYoutubeVideo ? (
            <div className="relative aspect-video w-full">
              <iframe 
                src={currentAd.url.replace('youtube.com/shorts/', 'youtube.com/embed/').split('?')[0]}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                onLoad={() => setIsVideoLoaded(true)}
              ></iframe>
              <div className="absolute inset-0" onClick={handleAdClick}></div>
            </div>
          ) : (
            <video 
              ref={videoRef}
              src={currentAd.url}
              className="w-full h-auto"
              controls={false}
              autoPlay
              onLoadedData={handleVideoLoaded}
              loop
              muted={isMuted}
              playsInline
              preload="auto"
            />
          )}
          
          {/* Audio track (separate from video for more control) */}
          {currentAd.audioUrl && !currentAd.isYoutubeVideo && (
            <audio
              ref={audioRef}
              src={currentAd.audioUrl}
              loop
              muted={isMuted}
              preload="auto"
            />
          )}

          {/* Ad overlay with controls */}
          <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/70 to-transparent p-3 flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <span className="text-white text-xs font-bold px-2 py-0.5 rounded bg-primary/80">AD</span>
              <p className="text-white text-sm font-medium animate-slide-up">{currentAd.title}</p>
            </div>
            <div className="flex items-center space-x-2">
              {!currentAd.isYoutubeVideo && (
                <Button 
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleMute();
                  }} 
                  variant="ghost" 
                  size="icon" 
                  className="h-7 w-7 text-white hover:bg-white/20"
                >
                  {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
              )}
              
              {canSkip && (
                <Button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSkip();
                  }} 
                  variant="ghost" 
                  size="icon" 
                  className="h-7 w-7 text-white hover:bg-white/20"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
          
          {/* Time and CTA buttons */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3 flex justify-between items-center">
            <div className="text-white text-sm">
              {!canSkip ? (
                <span>Ad will be skippable in {Math.max(Math.ceil(SKIP_DELAY/1000 - (currentAd.duration - adTimeRemaining)), 0)}s</span>
              ) : (
                <span>Ad: {adTimeRemaining}s remaining</span>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              {canSkip && (
                <Button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSkip();
                  }}
                  className="bg-primary/90 hover:bg-primary animate-shadow-pulse text-xs py-1 h-8"
                  size="sm"
                >
                  Skip Ad
                </Button>
              )}
              
              <Button 
                onClick={(e) => {
                  e.stopPropagation();
                  handleAdClick();
                }}
                className="bg-white/90 hover:bg-white text-black text-xs py-1 h-8 flex items-center"
                size="sm"
              >
                <ExternalLink className="h-3 w-3 mr-1" /> Visit Site
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
