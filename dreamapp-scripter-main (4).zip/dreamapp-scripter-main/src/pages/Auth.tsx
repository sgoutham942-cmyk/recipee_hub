
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { signupSchema, type SignupFormData } from "@/schemas/authSchema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  const form = useForm<SignupFormData>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
    },
  });

  // Check if we should default to signup tab
  useEffect(() => {
    const authAction = localStorage.getItem("authAction");
    if (authAction === "signup") {
      setIsLogin(false);
      localStorage.removeItem("authAction");
    }
  }, []);

  const onSubmit = (data: SignupFormData) => {
    if (isLogin) {
      // Mock login
      toast({
        title: "Logged in successfully",
        description: "Welcome back to RecipeHub!",
      });
      
      localStorage.setItem("isLoggedIn", "true");
      
      if (data.email.includes("premium")) {
        localStorage.setItem("isSubscribed", "true");
      }
      
      window.dispatchEvent(new Event('storage'));
      navigate("/");
    } else {
      // Mock registration
      toast({
        title: "Account created",
        description: "Your account has been created successfully!",
      });
      
      localStorage.setItem("isLoggedIn", "true");
      window.dispatchEvent(new Event('storage'));
      setIsLogin(true);
      navigate("/");
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <div className="flex flex-col justify-center flex-1 px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
        <div className="w-full max-w-sm mx-auto lg:w-96">
          <div>
            <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
              {isLogin ? "Sign in to your account" : "Create a new account"}
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              {isLogin ? "Don't have an account? " : "Already have an account? "}
              <button
                onClick={() => {
                  setIsLogin(!isLogin);
                  form.reset();
                }}
                className="font-medium text-primary hover:text-primary/80"
              >
                {isLogin ? "Sign up" : "Sign in"}
              </button>
            </p>
          </div>

          <div className="mt-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {!isLogin && (
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input {...field} autoComplete="name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email address</FormLabel>
                      <FormControl>
                        <Input {...field} type="email" autoComplete="email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="password" 
                          autoComplete={isLogin ? "current-password" : "new-password"} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {isLogin && (
                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <a href="#" className="font-medium text-primary hover:text-primary/80">
                        Forgot your password?
                      </a>
                    </div>
                  </div>
                )}

                <Button type="submit" className="w-full">
                  {isLogin ? "Sign in" : "Sign up"}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
      <div className="relative flex-1 hidden w-0 lg:block">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: "url('https://source.unsplash.com/random/?food,cooking')",
            backgroundSize: "cover",
            backgroundPosition: "center"
          }}
        >
          <div className="absolute inset-0 bg-primary/20 backdrop-blur-sm"></div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
