
import { useState } from "react";
import { Nav } from "@/components/Nav";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Check, CreditCard, Smartphone, Star, Building, CreditCard as CreditCardIcon, Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BackButton } from "@/components/BackButton";
import { Link } from "react-router-dom";

const SubscriptionPage = () => {
  const {
    toast
  } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string | null>(null);
  const [email, setEmail] = useState("");

  const handlePlanSelect = (plan: string) => {
    setSelectedPlan(plan);
    setShowPaymentForm(true);
    window.scrollTo({
      top: document.getElementById('payment-section')?.offsetTop,
      behavior: 'smooth'
    });
  };

  const handlePaymentClick = (method: string) => {
    setSelectedPaymentMethod(method);
    toast({
      title: "Payment Method Selected",
      description: `You selected ${method} as your payment method.`
    });
  };

  const handleSubscribe = () => {
    if (!selectedPaymentMethod) {
      toast({
        title: "Please select a payment method",
        description: "You need to select a payment method to proceed.",
        variant: "destructive"
      });
      return;
    }
    
    // Set subscription in localStorage
    localStorage.setItem("isSubscribed", "true");
    
    // Trigger storage event to notify other components of the change
    window.dispatchEvent(new Event('storage'));
    
    toast({
      title: "Subscription Successful!",
      description: `You have successfully subscribed to the ${selectedPlan} plan using ${selectedPaymentMethod}. You will no longer see advertisements.`
    });
    
    // In a real app, this would process the payment and update the user's subscription status in the database
  };

  return <div className="min-h-screen bg-gray-900">
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-between">
            <BackButton />
            <Link to="/">
              <Button variant="outline" className="flex items-center gap-2">
                <Home className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
          
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Premium Subscription</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Unlock all premium features and take your cooking experience to the next level with our subscription plans.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {/* Basic Plan */}
            <Card className="bg-gray-800/50 border-gray-700 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Basic</CardTitle>
                <CardDescription>For casual cooking enthusiasts</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold text-white">$4.99</span>
                  <span className="text-gray-400 ml-1">/month</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {["Ad-free experience", "Save up to 20 recipes", "Basic meal planner"].map(feature => <li key={feature} className="flex items-center text-gray-300">
                      <Check className="h-5 w-5 text-primary mr-2" />
                      {feature}
                    </li>)}
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => handlePlanSelect("Basic Plan ($4.99/month)")}>
                  Select Plan
                </Button>
              </CardFooter>
            </Card>
            
            {/* Premium Plan */}
            <Card className="bg-primary/10 border-primary/20 shadow-lg relative">
              <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-3 py-1 text-xs rounded-bl-lg rounded-tr-lg font-medium">
                POPULAR
              </div>
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  Premium <Star className="h-5 w-5 ml-2 text-yellow-400" />
                </CardTitle>
                <CardDescription>For serious home cooks</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold text-white">$9.99</span>
                  <span className="text-gray-400 ml-1">/month</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {["Everything in Basic", "Unlimited saved recipes", "Advanced meal planner", "Weekly premium recipes", "Cooking technique videos"].map(feature => <li key={feature} className="flex items-center text-gray-300">
                      <Check className="h-5 w-5 text-primary mr-2" />
                      {feature}
                    </li>)}
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => handlePlanSelect("Premium Plan ($9.99/month)")}>
                  Select Plan
                </Button>
              </CardFooter>
            </Card>
            
            {/* Professional Plan */}
            <Card className="bg-gray-800/50 border-gray-700 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Professional</CardTitle>
                <CardDescription>For culinary professionals</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold text-white">$19.99</span>
                  <span className="text-gray-400 ml-1">/month</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {["Everything in Premium", "Professional-grade recipes", "Menu planning tools", "Recipe scaling calculator", "Priority support", "Early access to new features"].map(feature => <li key={feature} className="flex items-center text-gray-300">
                      <Check className="h-5 w-5 text-primary mr-2" />
                      {feature}
                    </li>)}
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => handlePlanSelect("Professional Plan ($19.99/month)")}>
                  Select Plan
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          {showPaymentForm && <div id="payment-section" className="bg-gray-800/50 rounded-xl p-8 mb-16 border border-gray-700">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Complete Your Subscription</h2>
                  <div className="mb-8">
                    <div className="bg-gray-700/40 p-4 rounded-lg mb-4">
                      <h3 className="text-lg font-medium text-white mb-2">Selected Plan</h3>
                      <p className="text-primary font-medium">{selectedPlan}</p>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <Label htmlFor="email" className="text-white">Contact information</Label>
                        <Input id="email" type="email" placeholder="Email address" className="mt-2 bg-gray-700/40 border-gray-600 text-white" value={email} onChange={e => setEmail(e.target.value)} />
                      </div>
                      
                      <div>
                        <h3 className="text-white mb-3">Payment method</h3>
                        <div className="space-y-3 bg-zinc-800">
                          <div className={`flex items-center justify-between p-4 rounded-lg border cursor-pointer transition-all ${selectedPaymentMethod === "Credit Card" ? "border-primary bg-primary/10" : "border-gray-700 hover:border-gray-500"}`} onClick={() => handlePaymentClick("Credit Card")}>
                            <div className="flex items-center gap-3">
                              <input type="radio" checked={selectedPaymentMethod === "Credit Card"} onChange={() => {}} className="h-4 w-4 text-primary" />
                              <div>
                                <span className="text-white">Card</span>
                              </div>
                            </div>
                            <div className="flex gap-1">
                              <img src="https://cdn.jsdelivr.net/gh/alphardex/static@master/visa.svg" alt="Visa" className="h-6" />
                              <img src="https://cdn.jsdelivr.net/gh/alphardex/static@master/mastercard.svg" alt="Mastercard" className="h-6" />
                              <img src="https://cdn.jsdelivr.net/gh/alphardex/static@master/amex.svg" alt="American Express" className="h-6" />
                            </div>
                          </div>
                          
                          <div className={`flex items-center justify-between p-4 rounded-lg border cursor-pointer transition-all ${selectedPaymentMethod === "Amazon Pay" ? "border-primary bg-primary/10" : "border-gray-700 hover:border-gray-500"}`} onClick={() => handlePaymentClick("Amazon Pay")}>
                            <div className="flex items-center gap-3">
                              <input type="radio" checked={selectedPaymentMethod === "Amazon Pay"} onChange={() => {}} className="h-4 w-4 text-primary" />
                              <div>
                                <span className="text-white">Amazon Pay</span>
                              </div>
                            </div>
                            <div>
                              <img src="https://cdn.jsdelivr.net/gh/alphardex/static@master/amazonpay.svg" alt="Amazon Pay" className="h-6" />
                            </div>
                          </div>
                          
                          <div className={`flex items-center justify-between p-4 rounded-lg border cursor-pointer transition-all ${selectedPaymentMethod === "Cash App Pay" ? "border-primary bg-primary/10" : "border-gray-700 hover:border-gray-500"}`} onClick={() => handlePaymentClick("Cash App Pay")}>
                            <div className="flex items-center gap-3">
                              <input type="radio" checked={selectedPaymentMethod === "Cash App Pay"} onChange={() => {}} className="h-4 w-4 text-primary" />
                              <div>
                                <span className="text-white">Cash App Pay</span>
                              </div>
                            </div>
                            <div>
                              <span className="text-green-500 text-2xl font-bold">$</span>
                            </div>
                          </div>
                          
                          <div className={`flex items-center justify-between p-4 rounded-lg border cursor-pointer transition-all ${selectedPaymentMethod === "UPI Payment" ? "border-primary bg-primary/10" : "border-gray-700 hover:border-gray-500"}`} onClick={() => handlePaymentClick("UPI Payment")}>
                            <div className="flex items-center gap-3">
                              <input type="radio" checked={selectedPaymentMethod === "UPI Payment"} onChange={() => {}} className="h-4 w-4 text-primary" />
                              <div>
                                <span className="text-white">UPI Payment</span>
                                <p className="text-xs text-gray-400">Paytm, PhonePe, Google Pay</p>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <img src="https://1000logos.net/wp-content/uploads/2021/03/Paytm_Logo.png" alt="Paytm" className="h-5 object-contain" />
                              <img src="https://download.logo.wine/logo/PhonePe/PhonePe-Logo.wine.png" alt="PhonePe" className="h-5 object-contain" />
                              <img src="https://cdn.worldvectorlogo.com/logos/google-pay-1.svg" alt="Google Pay" className="h-5 object-contain" />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="save-info" className="h-4 w-4 text-primary" />
                        <Label htmlFor="save-info" className="text-gray-300 text-sm">Securely save my information for 1-click checkout</Label>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Order Summary</h2>
                  <div className="bg-gray-700/40 p-6 rounded-lg">
                    <div className="space-y-4 mb-6">
                      <div className="flex justify-between">
                        <span className="text-gray-300">{selectedPlan}</span>
                        <span className="text-white font-medium">${selectedPlan?.includes("Basic") ? "4.99" : selectedPlan?.includes("Premium") ? "9.99" : "19.99"}</span>
                      </div>
                      <Separator className="bg-gray-600" />
                      <div className="flex justify-between">
                        <span className="text-gray-300">Subtotal</span>
                        <span className="text-white font-medium">${selectedPlan?.includes("Basic") ? "4.99" : selectedPlan?.includes("Premium") ? "9.99" : "19.99"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Tax</span>
                        <span className="text-white font-medium">$0.00</span>
                      </div>
                      <Separator className="bg-gray-600" />
                      <div className="flex justify-between">
                        <span className="text-gray-300 font-medium">Total due today</span>
                        <span className="text-white font-bold">${selectedPlan?.includes("Basic") ? "4.99" : selectedPlan?.includes("Premium") ? "9.99" : "19.99"}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <Button className="w-full py-6 text-base" onClick={handleSubscribe}>
                        Subscribe
                      </Button>
                      <p className="text-xs text-gray-400 text-center">
                        By confirming your subscription, you allow Recipe Hub to charge you for future payments in accordance with their terms. You can cancel your subscription at any time.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>}
          
          <div className="bg-gray-800/50 rounded-xl p-8 mb-16">
            <h2 className="text-2xl font-bold text-white mb-6 text-center">Our Payment Partners</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Credit Card */}
              <div className="flex flex-col items-center border border-gray-700 rounded-lg p-6 cursor-pointer hover:bg-gray-800/70 transition" onClick={() => {
              if (selectedPlan) {
                handlePaymentClick("Credit Card");
              } else {
                toast({
                  title: "Please select a plan first",
                  description: "You need to select a subscription plan before choosing a payment method."
                });
              }
            }}>
                <CreditCardIcon className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">Credit Card</h3>
                <p className="text-gray-400 text-center text-sm">Visa, Mastercard, American Express and more</p>
              </div>
              
              {/* Amazon Pay */}
              <div className="flex flex-col items-center border border-gray-700 rounded-lg p-6 cursor-pointer hover:bg-gray-800/70 transition" onClick={() => {
              if (selectedPlan) {
                handlePaymentClick("Amazon Pay");
              } else {
                toast({
                  title: "Please select a plan first",
                  description: "You need to select a subscription plan before choosing a payment method."
                });
              }
            }}>
                <div className="h-12 w-12 flex items-center justify-center text-white mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                    <path d="M35.5 19.5C35.5 19.1 35.5 18.7 35.5 18.4C35.5 18 35.5 17.6 35.4 17.3C35.4 16.9 35.3 16.5 35.2 16.2C35.1 15.8 35 15.5 34.9 15.1C34.8 14.8 34.6 14.4 34.4 14.1C34.2 13.8 34 13.5 33.8 13.2C33.6 12.9 33.3 12.7 33.1 12.4C32.8 12.2 32.5 12 32.2 11.8C31.9 11.6 31.6 11.4 31.3 11.3C31 11.1 30.6 11 30.3 10.9C30 10.8 29.6 10.7 29.2 10.7C28.9 10.6 28.5 10.6 28.1 10.6C27.8 10.6 27.4 10.6 27 10.6H20.9C20.5 10.6 20.1 10.6 19.8 10.6C19.4 10.6 19 10.6 18.7 10.7C18.3 10.7 17.9 10.8 17.6 10.9C17.2 11 16.9 11.1 16.6 11.3C16.3 11.4 16 11.6 15.7 11.8C15.4 12 15.1 12.2 14.8 12.4C14.6 12.7 14.3 12.9 14.1 13.2C13.9 13.5 13.7 13.8 13.5 14.1C13.3 14.4 13.1 14.8 13 15.1C12.9 15.5 12.8 15.8 12.7 16.2C12.6 16.5 12.5 16.9 12.5 17.3C12.5 17.6 12.4 18 12.4 18.4C12.4 18.7 12.4 19.1 12.4 19.5V20V28.8V29.3C12.4 29.7 12.4 30.1 12.4 30.4C12.4 30.8 12.4 31.2 12.5 31.5C12.5 31.9 12.6 32.3 12.7 32.6C12.8 33 12.9 33.3 13 33.7C13.1 34 13.3 34.4 13.5 34.7C13.7 35 13.9 35.3 14.1 35.6C14.3 35.9 14.6 36.1 14.8 36.4C15.1 36.6 15.4 36.8 15.7 37C16 37.2 16.3 37.4 16.6 37.5C16.9 37.7 17.3 37.8 17.6 37.9C17.9 38 18.3 38.1 18.7 38.1C19 38.2 19.4 38.2 19.8 38.2C20.1 38.2 20.5 38.2 20.9 38.2H27C27.4 38.2 27.8 38.2 28.1 38.2C28.5 38.2 28.9 38.2 29.2 38.1C29.6 38.1 30 38 30.3 37.9C30.7 37.8 31 37.7 31.3 37.5C31.6 37.4 31.9 37.2 32.2 37C32.5 36.8 32.8 36.6 33.1 36.4C33.3 36.1 33.6 35.9 33.8 35.6C34 35.3 34.2 35 34.4 34.7C34.6 34.4 34.8 34 34.9 33.7C35 33.3 35.1 33 35.2 32.6C35.3 32.3 35.4 31.9 35.4 31.5C35.5 31.2 35.5 30.8 35.5 30.4C35.5 30.1 35.5 29.7 35.5 29.3V28.8V20V19.5ZM32.7 28.7C32.7 29 32.7 29.3 32.7 29.5C32.7 29.8 32.7 30.1 32.6 30.3C32.6 30.6 32.5 30.9 32.5 31.1C32.4 31.4 32.3 31.6 32.3 31.9C32.2 32.1 32.1 32.4 32 32.6C31.9 32.8 31.7 33 31.6 33.2C31.4 33.4 31.3 33.6 31.1 33.8C30.9 34 30.7 34.1 30.4 34.3C30.2 34.4 30 34.6 29.7 34.7C29.5 34.8 29.2 34.9 29 35C28.7 35.1 28.5 35.1 28.2 35.2C27.9 35.2 27.7 35.3 27.4 35.3C27.1 35.3 26.9 35.3 26.6 35.3H21.5C21.2 35.3 21 35.3 20.7 35.3C20.4 35.3 20.2 35.3 19.9 35.2C19.6 35.2 19.4 35.1 19.1 35C18.9 35 18.6 34.8 18.4 34.7C18.1 34.6 17.9 34.5 17.7 34.3C17.5 34.1 17.2 34 17 33.8C16.8 33.6 16.7 33.4 16.5 33.2C16.4 33 16.2 32.8 16.1 32.6C16 32.4 15.9 32.1 15.8 31.9C15.7 31.6 15.6 31.4 15.6 31.1C15.5 30.9 15.5 30.6 15.4 30.3C15.4 30 15.3 29.8 15.3 29.5C15.3 29.2 15.3 29 15.3 28.7V20.2C15.3 19.9 15.3 19.7 15.3 19.4C15.3 19.1 15.3 18.9 15.4 18.6C15.4 18.3 15.5 18.1 15.6 17.8C15.6 17.5 15.7 17.3 15.8 17.1C15.9 16.8 16 16.6 16.1 16.3C16.2 16.1 16.4 15.9 16.5 15.7C16.7 15.5 16.8 15.3 17 15.1C17.2 14.9 17.4 14.8 17.7 14.6C17.9 14.5 18.1 14.3 18.4 14.2C18.6 14.1 18.9 14 19.1 14C19.4 13.9 19.6 13.9 19.9 13.8C20.2 13.8 20.4 13.7 20.7 13.7C21 13.7 21.2 13.7 21.5 13.7H26.6C26.9 13.7 27.1 13.7 27.4 13.7C27.7 13.7 27.9 13.7 28.2 13.8C28.5 13.8 28.7 13.9 29 14C29.2 14 29.5 14.1 29.7 14.2C30 14.3 30.2 14.4 30.4 14.6C30.6 14.7 30.9 14.9 31.1 15.1C31.3 15.3 31.4 15.5 31.6 15.7C31.7 15.9 31.9 16.1 32 16.3C32.1 16.5 32.2 16.8 32.3 17.1C32.4 17.3 32.4 17.5 32.5 17.8C32.6 18.1 32.6 18.3 32.6 18.6C32.7 18.9 32.7 19.1 32.7 19.4C32.7 19.7 32.7 19.9 32.7 20.2V28.7Z" fill="#F79B0E" />
                    <path d="M23.8 22.4C23.8 21.1 24.9 20 26.2 20C27.5 20 28.6 21.1 28.6 22.4C28.6 23.7 27.5 24.8 26.2 24.8C24.9 24.8 23.8 23.7 23.8 22.4Z" fill="#F79B0E" />
                    <path d="M19.3 29.8C19.3 28.5 20.4 27.4 21.7 27.4C23 27.4 24.1 28.5 24.1 29.8C24.1 31.1 23 32.2 21.7 32.2C20.4 32.2 19.3 31.1 19.3 29.8Z" fill="#F79B0E" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-white mb-2">Amazon Pay</h3>
                <p className="text-gray-400 text-center text-sm">Fast and secure checkout with Amazon</p>
              </div>
              
              {/* Cash App Pay */}
              <div className="flex flex-col items-center border border-gray-700 rounded-lg p-6 cursor-pointer hover:bg-gray-800/70 transition" onClick={() => {
              if (selectedPlan) {
                handlePaymentClick("Cash App Pay");
              } else {
                toast({
                  title: "Please select a plan first",
                  description: "You need to select a subscription plan before choosing a payment method."
                });
              }
            }}>
                <div className="h-12 w-12 flex items-center justify-center mb-4">
                  <div className="bg-green-500 text-white h-10 w-10 flex items-center justify-center rounded-md">
                    <span className="text-2xl font-bold">$</span>
                  </div>
                </div>
                <h3 className="text-lg font-medium text-white mb-2">Cash App Pay</h3>
                <p className="text-gray-400 text-center text-sm">Quick payments with Cash App</p>
              </div>
              
              {/* UPI Payment */}
              <div className="flex flex-col items-center border border-gray-700 rounded-lg p-6 cursor-pointer hover:bg-gray-800/70 transition" onClick={() => {
              if (selectedPlan) {
                handlePaymentClick("UPI Payment");
              } else {
                toast({
                  title: "Please select a plan first",
                  description: "You need to select a subscription plan before choosing a payment method."
                });
              }
            }}>
                <Smartphone className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">UPI Payment</h3>
                <p className="text-gray-400 text-center text-sm">Paytm, PhonePe and Google Pay</p>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Have Questions?</h2>
            <p className="text-gray-400 mb-6">
              Our support team is here to help you with any questions about our subscription plans.
            </p>
            <Button variant="outline">Contact Support</Button>
          </div>
        </div>
      </main>
    </div>;
};

export default SubscriptionPage;
