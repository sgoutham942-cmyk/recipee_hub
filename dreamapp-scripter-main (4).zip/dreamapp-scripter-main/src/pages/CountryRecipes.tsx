
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { mealApi } from "@/services/mealApi";
import { Nav } from "@/components/Nav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Clock, Users, Globe } from "lucide-react";
import { Link } from "react-router-dom";
import { BackButton } from "@/components/BackButton";
import { Skeleton } from "@/components/ui/skeleton";
import { useState, useEffect } from "react";
import { toast } from "@/hooks/use-toast";

const CountryRecipesPage = () => {
  const { country } = useParams<{ country: string }>();
  const [favorites, setFavorites] = useState<Record<string, boolean>>({});

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    if (savedFavorites) {
      const favoritesArray = JSON.parse(savedFavorites);
      const favoritesMap: Record<string, boolean> = {};
      favoritesArray.forEach((fav: any) => {
        favoritesMap[fav.idMeal] = true;
      });
      setFavorites(favoritesMap);
    }
  }, []);

  const { data: recipes, isLoading } = useQuery({
    queryKey: ["recipesByCountry", country],
    queryFn: () => mealApi.getMealsByArea(country || ""),
    enabled: !!country,
  });

  const toggleFavorite = (recipe: any, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Get current favorites from localStorage
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    let favoritesArray = savedFavorites ? JSON.parse(savedFavorites) : [];
    
    if (favorites[recipe.idMeal]) {
      // Remove from favorites
      favoritesArray = favoritesArray.filter((fav: any) => fav.idMeal !== recipe.idMeal);
      toast({
        title: "Removed from favorites",
        description: `${recipe.strMeal} has been removed from your favorites`,
      });
    } else {
      // Add to favorites
      const recipeToSave = {
        idMeal: recipe.idMeal,
        strMeal: recipe.strMeal,
        strMealThumb: recipe.strMealThumb,
        strCategory: recipe.strCategory
      };
      favoritesArray.push(recipeToSave);
      toast({
        title: "Added to favorites",
        description: `${recipe.strMeal} has been added to your favorites`,
      });
    }
    
    // Save back to localStorage
    localStorage.setItem('favoriteRecipes', JSON.stringify(favoritesArray));
    
    // Update the UI
    setFavorites(prev => ({
      ...prev,
      [recipe.idMeal]: !prev[recipe.idMeal]
    }));
  };

  // Get country flag
  const getCountryFlag = (country: string) => {
    const countryCodeMap: Record<string, string> = {
      'American': 'us',
      'British': 'gb',
      'Canadian': 'ca',
      'Chinese': 'cn',
      'Dutch': 'nl',
      'Egyptian': 'eg',
      'French': 'fr',
      'Greek': 'gr',
      'Indian': 'in',
      'Irish': 'ie',
      'Italian': 'it',
      'Jamaican': 'jm',
      'Japanese': 'jp',
      'Kenyan': 'ke',
      'Malaysian': 'my',
      'Mexican': 'mx',
      'Moroccan': 'ma',
      'Polish': 'pl',
      'Portuguese': 'pt',
      'Russian': 'ru',
      'Spanish': 'es',
      'Thai': 'th',
      'Tunisian': 'tn',
      'Turkish': 'tr',
      'Vietnamese': 'vn'
    };

    const code = countryCodeMap[country] || 'unknown';
    if (code === 'unknown') return null;
    return `https://flagcdn.com/96x72/${code}.png`;
  };

  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center -z-10"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2940&auto=format&fit=crop")',
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0,0,0,0.85)'
        }}
      />
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <BackButton />
              <h1 className="text-4xl font-bold text-white flex items-center gap-3">
                {country} Recipes
                {getCountryFlag(country || "") && (
                  <img 
                    src={getCountryFlag(country || "")} 
                    alt={`${country} flag`} 
                    className="h-8 rounded shadow-sm"
                  />
                )}
              </h1>
            </div>
            <div>
              <Link to="/recipes">
                <Button variant="outline">All Recipes</Button>
              </Link>
            </div>
          </div>

          {isLoading ? (
            // Loading skeletons
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array(9).fill(0).map((_, index) => (
                <Card key={index} className="bg-gray-800/50 border-gray-700">
                  <div className="space-y-4">
                    <Skeleton className="h-48 w-full rounded-t-lg" />
                    <div className="p-4">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/4 mb-4" />
                      <div className="flex justify-between">
                        <Skeleton className="h-4 w-1/3" />
                        <Skeleton className="h-4 w-1/3" />
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : recipes && recipes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {recipes.map((recipe) => (
                <Card key={recipe.idMeal} className="bg-gray-800/50 border-gray-700">
                  <Link to={`/recipe/${recipe.idMeal}`}>
                    <div className="relative aspect-video overflow-hidden rounded-t-lg">
                      <img
                        src={recipe.strMealThumb}
                        alt={recipe.strMeal}
                        className="object-cover w-full h-full transform hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-semibold text-white">{recipe.strMeal}</h3>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className={`${favorites[recipe.idMeal] ? 'text-red-500' : 'text-gray-400'} hover:text-red-400`}
                          onClick={(e) => toggleFavorite(recipe, e)}
                        >
                          <Heart className="h-5 w-5" fill={favorites[recipe.idMeal] ? "currentColor" : "none"} />
                        </Button>
                      </div>
                      <div className="flex items-center gap-4 text-gray-400 text-sm mt-4">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          30 mins
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          4 servings
                        </div>
                      </div>
                    </div>
                  </Link>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Globe className="mx-auto h-16 w-16 text-gray-400 mb-4" />
              <h2 className="text-2xl font-semibold text-white mb-2">No recipes found</h2>
              <p className="text-gray-300 mb-6">We couldn't find any recipes for this country.</p>
              <Link to="/recipes">
                <Button>Browse all recipes</Button>
              </Link>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default CountryRecipesPage;
