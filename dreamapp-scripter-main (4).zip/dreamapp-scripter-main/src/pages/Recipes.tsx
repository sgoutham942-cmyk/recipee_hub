
import { Nav } from "@/components/Nav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Clock, Users, Search, X, Bookmark, Globe, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { BackButton } from "@/components/BackButton";
import { useQuery } from "@tanstack/react-query";
import { mealApi } from "@/services/mealApi";
import { Skeleton } from "@/components/ui/skeleton";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

const RecipesPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [favorites, setFavorites] = useState<Record<string, boolean>>({});
  const [userRecipes, setUserRecipes] = useState<any[]>([]);

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    if (savedFavorites) {
      const favoritesArray = JSON.parse(savedFavorites);
      const favoritesMap: Record<string, boolean> = {};
      favoritesArray.forEach((fav: any) => {
        favoritesMap[fav.idMeal] = true;
      });
      setFavorites(favoritesMap);
    }
    
    // Load user recipes
    const savedUserRecipes = localStorage.getItem('userRecipes');
    if (savedUserRecipes) {
      setUserRecipes(JSON.parse(savedUserRecipes));
    }
  }, []);

  const { data: defaultRecipes, isLoading: isLoadingDefault } = useQuery({
    queryKey: ["recipes"],
    queryFn: async () => {
      // Fetch recipes from vegetarian-friendly categories (excluding beef and pork)
      const categories = ["Seafood", "Chicken", "Vegetarian", "Vegan", "Pasta", "Dessert"];
      const promises = categories.map(category => mealApi.getMealsByCategory(category));
      const results = await Promise.all(promises);
      // Combine and take first few from each category
      return results.flatMap(categoryMeals => categoryMeals.slice(0, 4));
    },
    enabled: !isSearching,
  });

  const { data: searchResults, isLoading: isLoadingSearch } = useQuery({
    queryKey: ["searchRecipes", searchTerm],
    queryFn: () => mealApi.searchMeals(searchTerm),
    enabled: isSearching && searchTerm.length > 0,
  });

  // Combine API recipes with user recipes
  const allRecipes = () => {
    let recipesToShow = [];
    
    if (isSearching) {
      // When searching, filter both API results and user recipes
      const apiResults = searchResults || [];
      const filteredUserRecipes = userRecipes.filter(recipe => 
        recipe.strMeal.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.strCategory.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (recipe.strInstructions && recipe.strInstructions.toLowerCase().includes(searchTerm.toLowerCase()))
      );
      recipesToShow = [...apiResults, ...filteredUserRecipes];
    } else {
      // For default view, combine API recipes with user recipes
      const apiRecipes = defaultRecipes || [];
      recipesToShow = [...apiRecipes, ...userRecipes];
    }
    
    return recipesToShow;
  };

  const isLoading = isSearching ? isLoadingSearch : isLoadingDefault;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      setIsSearching(true);
    }
  };

  const clearSearch = () => {
    setSearchTerm("");
    setIsSearching(false);
  };

  const toggleFavorite = (recipe: any, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Get current favorites from localStorage
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    let favoritesArray = savedFavorites ? JSON.parse(savedFavorites) : [];
    
    if (favorites[recipe.idMeal]) {
      // Remove from favorites
      favoritesArray = favoritesArray.filter((fav: any) => fav.idMeal !== recipe.idMeal);
      toast({
        title: "Removed from favorites",
        description: `${recipe.strMeal} has been removed from your favorites`,
      });
    } else {
      // Add to favorites
      const recipeToSave = {
        idMeal: recipe.idMeal,
        strMeal: recipe.strMeal,
        strMealThumb: recipe.strMealThumb,
        strCategory: recipe.strCategory
      };
      favoritesArray.push(recipeToSave);
      toast({
        title: "Added to favorites",
        description: `${recipe.strMeal} has been added to your favorites`,
      });
    }
    
    // Save back to localStorage
    localStorage.setItem('favoriteRecipes', JSON.stringify(favoritesArray));
    
    // Update the UI
    setFavorites(prev => ({
      ...prev,
      [recipe.idMeal]: !prev[recipe.idMeal]
    }));
  };

  const deleteUserRecipe = (recipe: any, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (window.confirm(`Are you sure you want to delete "${recipe.strMeal}"?`)) {
      // Remove from user recipes
      const updatedRecipes = userRecipes.filter((r) => r.idMeal !== recipe.idMeal);
      localStorage.setItem('userRecipes', JSON.stringify(updatedRecipes));
      setUserRecipes(updatedRecipes);
      
      // Also remove from favorites if it's there
      if (favorites[recipe.idMeal]) {
        const savedFavorites = localStorage.getItem('favoriteRecipes');
        let favoritesArray = savedFavorites ? JSON.parse(savedFavorites) : [];
        favoritesArray = favoritesArray.filter((fav: any) => fav.idMeal !== recipe.idMeal);
        localStorage.setItem('favoriteRecipes', JSON.stringify(favoritesArray));
        
        setFavorites(prev => {
          const newFavorites = {...prev};
          delete newFavorites[recipe.idMeal];
          return newFavorites;
        });
      }
      
      toast({
        title: "Recipe Deleted",
        description: `${recipe.strMeal} has been deleted`,
      });
    }
  };

  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center -z-10"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2940&auto=format&fit=crop")',
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0,0,0,0.85)'
        }}
      />
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <BackButton />
              <h1 className="text-4xl font-bold text-white">Recipes</h1>
            </div>
            <div className="flex gap-2">
              <Link to="/countries">
                <Button variant="outline" className="gap-2">
                  <Globe className="h-5 w-5" />
                  <span className="hidden sm:inline">By Country</span>
                </Button>
              </Link>
              <Link to="/favorites">
                <Button variant="outline" className="gap-2">
                  <Bookmark className="h-5 w-5" />
                  <span className="hidden sm:inline">My Favorites</span>
                </Button>
              </Link>
              <Link to="/add-recipe">
                <Button>Add New Recipe</Button>
              </Link>
            </div>
          </div>

          {/* Search bar */}
          <div className="mb-8">
            <form onSubmit={handleSearch} className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type="text"
                  placeholder="Search recipes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full h-12 pl-12 pr-4 rounded-lg bg-white/90 backdrop-blur-sm"
                />
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                {searchTerm && (
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="absolute right-2 top-1/2 transform -translate-y-1/2" 
                    onClick={clearSearch}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                )}
              </div>
              <Button type="submit" className="h-12 px-6">Search</Button>
            </form>
          </div>

          {/* User-created recipes section */}
          {userRecipes.length > 0 && !isSearching && (
            <div className="mb-10">
              <h2 className="text-2xl font-semibold text-white mb-6">Your Recipes</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-10">
                {userRecipes.map((recipe) => (
                  <Card key={recipe.idMeal} className="bg-gray-800/50 border-gray-700 relative">
                    <div className="absolute top-3 right-3 z-10">
                      <span className="bg-primary text-white text-xs font-medium px-2.5 py-1 rounded">Your Recipe</span>
                    </div>
                    <Link to={`/recipe/${recipe.idMeal}`}>
                      <div className="relative aspect-video overflow-hidden rounded-t-lg">
                        <img
                          src={recipe.strMealThumb}
                          alt={recipe.strMeal}
                          className="object-cover w-full h-full transform hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <div className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-xl font-semibold text-white">{recipe.strMeal}</h3>
                          <div className="flex">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className={`${favorites[recipe.idMeal] ? 'text-red-500' : 'text-gray-400'} hover:text-red-400`}
                              onClick={(e) => toggleFavorite(recipe, e)}
                            >
                              <Heart className="h-5 w-5" fill={favorites[recipe.idMeal] ? "currentColor" : "none"} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              className="text-gray-400 hover:text-red-500"
                              onClick={(e) => deleteUserRecipe(recipe, e)}
                            >
                              <Trash2 className="h-5 w-5" />
                            </Button>
                          </div>
                        </div>
                        <p className="text-sm text-primary mb-4">{recipe.strCategory}</p>
                        <div className="flex items-center gap-4 text-gray-400 text-sm">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {recipe.cookTime} mins
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            {recipe.servings} servings
                          </div>
                        </div>
                      </div>
                    </Link>
                  </Card>
                ))}
              </div>
              
              {!isSearching && <div className="border-b border-gray-700 my-8"></div>}
            </div>
          )}

          {isSearching && allRecipes().length === 0 && !isLoading && (
            <div className="text-center py-8">
              <h2 className="text-2xl font-semibold text-white mb-2">No recipes found</h2>
              <p className="text-gray-300 mb-4">Try searching with different keywords</p>
              <Button onClick={clearSearch} variant="outline">
                Show all recipes
              </Button>
            </div>
          )}

          {!isSearching && <h2 className="text-2xl font-semibold text-white mb-6">Popular Recipes</h2>}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {isLoading ? (
              // Loading skeletons
              Array(12).fill(0).map((_, index) => (
                <Card key={index} className="bg-gray-800/50 border-gray-700">
                  <div className="space-y-4">
                    <Skeleton className="h-48 w-full rounded-t-lg" />
                    <div className="p-4">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/4 mb-4" />
                      <div className="flex justify-between">
                        <Skeleton className="h-4 w-1/3" />
                        <Skeleton className="h-4 w-1/3" />
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            ) : (
              // If searching, show all recipes that match. Otherwise, show default recipes (excluding user recipes)
              (isSearching ? allRecipes() : defaultRecipes)?.map((recipe) => (
                <Card key={recipe.idMeal} className="bg-gray-800/50 border-gray-700">
                  {recipe.isUserCreated && (
                    <div className="absolute top-3 right-3 z-10">
                      <span className="bg-primary text-white text-xs font-medium px-2.5 py-1 rounded">Your Recipe</span>
                    </div>
                  )}
                  <Link to={`/recipe/${recipe.idMeal}`}>
                    <div className="relative aspect-video overflow-hidden rounded-t-lg">
                      <img
                        src={recipe.strMealThumb}
                        alt={recipe.strMeal}
                        className="object-cover w-full h-full transform hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-semibold text-white">{recipe.strMeal}</h3>
                        <div className="flex">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className={`${favorites[recipe.idMeal] ? 'text-red-500' : 'text-gray-400'} hover:text-red-400`}
                            onClick={(e) => toggleFavorite(recipe, e)}
                          >
                            <Heart className="h-5 w-5" fill={favorites[recipe.idMeal] ? "currentColor" : "none"} />
                          </Button>
                          {recipe.isUserCreated && (
                            <Button 
                              variant="ghost" 
                              size="icon"
                              className="text-gray-400 hover:text-red-500"
                              onClick={(e) => deleteUserRecipe(recipe, e)}
                            >
                              <Trash2 className="h-5 w-5" />
                            </Button>
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-primary mb-4">{recipe.strCategory}</p>
                      <div className="flex items-center gap-4 text-gray-400 text-sm">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {recipe.cookTime || 30} mins
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {recipe.servings || 4} servings
                        </div>
                      </div>
                    </div>
                  </Link>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default RecipesPage;
