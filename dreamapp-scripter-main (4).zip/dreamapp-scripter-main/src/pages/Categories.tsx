
import { Nav } from "@/components/Nav";
import { useQuery } from "@tanstack/react-query";
import { mealApi, type Category } from "@/services/mealApi";
import { Link } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const CategoriesPage = () => {
  const { data: allCategories, isLoading } = useQuery({
    queryKey: ["categories"],
    queryFn: mealApi.getCategories,
  });

  // Filter out beef and pork categories
  const categories = allCategories?.filter(
    (category: Category) => 
      category.strCategory.toLowerCase() !== "beef" && 
      category.strCategory.toLowerCase() !== "pork"
  );

  return (
    <div className="min-h-screen bg-gray-900">
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <Link to="/">
              <Button variant="ghost" className="flex items-center gap-2 text-white hover:text-primary">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
          
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Recipe Categories</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Explore our diverse collection of recipes across different categories. From quick breakfasts to elaborate dinners, find the perfect recipe for any occasion.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {isLoading ? (
              // Loading skeletons
              Array(8).fill(0).map((_, index) => (
                <div key={index} className="p-8 bg-gray-800/50 backdrop-blur-sm rounded-lg">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <Skeleton className="h-32 w-32 rounded-full" />
                    <Skeleton className="h-6 w-32" />
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-16 w-full" />
                  </div>
                </div>
              ))
            ) : (
              categories?.map((category: Category) => (
                <Link
                  key={category.idCategory}
                  to={`/category/${category.strCategory.toLowerCase()}`}
                  className="group p-8 bg-gray-800/50 backdrop-blur-sm rounded-lg hover:bg-gray-800/70 transition-all duration-300"
                >
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="w-32 h-32 rounded-full overflow-hidden group-hover:scale-110 transition-transform duration-300">
                      <img
                        src={category.strCategoryThumb}
                        alt={category.strCategory}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <h3 className="text-2xl font-semibold text-white">{category.strCategory}</h3>
                    <p className="text-gray-400 line-clamp-3">{category.strCategoryDescription}</p>
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default CategoriesPage;
