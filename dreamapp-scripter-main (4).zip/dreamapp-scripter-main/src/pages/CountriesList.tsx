
import { Nav } from "@/components/Nav";
import { BackButton } from "@/components/BackButton";
import { CountryList } from "@/components/CountryList";

const CountriesListPage = () => {
  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center -z-10"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1490818387583-1baba5e638af?q=80&w=2832&auto=format&fit=crop")',
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0,0,0,0.75)'
        }}
      />
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 mb-8">
            <BackButton />
            <h1 className="text-4xl font-bold text-white">Recipes by Country</h1>
          </div>
          
          <div className="bg-gray-900/70 backdrop-blur-sm rounded-xl p-6 shadow-xl">
            <CountryList />
          </div>
        </div>
      </main>
    </div>
  );
};

export default CountriesListPage;
