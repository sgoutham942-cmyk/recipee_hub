
import { Nav } from "@/components/Nav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Clock, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { BackButton } from "@/components/BackButton";
import { useEffect, useState } from "react";

// Define the Recipe type
interface Recipe {
  idMeal: string;
  strMeal: string;
  strMealThumb: string;
  strCategory?: string;
}

const FavoritesPage = () => {
  const [favorites, setFavorites] = useState<Recipe[]>([]);

  useEffect(() => {
    // Load favorites from localStorage
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  const removeFavorite = (recipeId: string) => {
    const updatedFavorites = favorites.filter(recipe => recipe.idMeal !== recipeId);
    setFavorites(updatedFavorites);
    localStorage.setItem('favoriteRecipes', JSON.stringify(updatedFavorites));
  };

  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center -z-10"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2940&auto=format&fit=crop")',
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0,0,0,0.85)'
        }}
      />
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 mb-8">
            <BackButton />
            <h1 className="text-4xl font-bold text-white">Favorite Recipes</h1>
          </div>

          {favorites.length === 0 ? (
            <div className="text-center py-16 bg-gray-800/50 rounded-lg border border-gray-700">
              <h2 className="text-2xl font-semibold text-white mb-4">No favorites yet</h2>
              <p className="text-gray-300 mb-6">Start adding recipes to your favorites to see them here</p>
              <Link to="/recipes">
                <Button>Browse Recipes</Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {favorites.map((recipe) => (
                <Card key={recipe.idMeal} className="bg-gray-800/50 border-gray-700">
                  <Link to={`/recipe/${recipe.idMeal}`}>
                    <div className="relative aspect-video overflow-hidden rounded-t-lg">
                      <img
                        src={recipe.strMealThumb}
                        alt={recipe.strMeal}
                        className="object-cover w-full h-full transform hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  </Link>
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-semibold text-white">{recipe.strMeal}</h3>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-red-500 hover:text-red-400"
                        onClick={() => removeFavorite(recipe.idMeal)}
                      >
                        <Heart className="h-5 w-5" fill="currentColor" />
                      </Button>
                    </div>
                    {recipe.strCategory && (
                      <p className="text-sm text-primary mb-4">{recipe.strCategory}</p>
                    )}
                    <div className="flex items-center gap-4 text-gray-400 text-sm">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        30 mins
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        4 servings
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default FavoritesPage;
