
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { ImagePlus } from "lucide-react";
import { BackButton } from "@/components/BackButton";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const recipeSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  category: z.string().min(1, { message: "Please select a category" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  ingredients: z.string().min(5, { message: "Ingredients required" }),
  instructions: z.string().min(20, { message: "Instructions must be at least 20 characters" }),
  cookTime: z.coerce.number().min(1, { message: "Cooking time required" }),
  servings: z.coerce.number().min(1, { message: "Servings required" }),
});

type RecipeFormValues = z.infer<typeof recipeSchema>;

// Define a more specific type for our recipe object
interface UserRecipe {
  idMeal: string;
  strMeal: string;
  strCategory: string;
  strArea: string;
  strInstructions: string;
  strMealThumb: string;
  strTags: string;
  strYoutube: string;
  strSource: string;
  isUserCreated: boolean;
  cookTime: number;
  servings: number;
  [key: string]: string | number | boolean; // Allow dynamic properties for ingredients and measures
}

const AddRecipe = () => {
  const [image, setImage] = useState<string | null>(null);
  const navigate = useNavigate();

  const form = useForm<RecipeFormValues>({
    resolver: zodResolver(recipeSchema),
    defaultValues: {
      title: "",
      category: "breakfast",
      description: "",
      ingredients: "",
      instructions: "",
      cookTime: 30,
      servings: 4,
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target?.result as string);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const onSubmit = (data: RecipeFormValues) => {
    const newRecipeId = `user-recipe-${Date.now()}`;
    
    const newRecipe: UserRecipe = {
      idMeal: newRecipeId,
      strMeal: data.title,
      strCategory: data.category,
      strArea: "Homemade",
      strInstructions: data.instructions,
      strMealThumb: image || "https://via.placeholder.com/400x300/333/fff?text=No+Image",
      strTags: data.category,
      strYoutube: "",
      strSource: "",
      isUserCreated: true,
      cookTime: data.cookTime,
      servings: data.servings,
    };

    const ingredientsLines = data.ingredients.split('\n').filter(line => line.trim() !== '');
    ingredientsLines.forEach((line, index) => {
      const parts = line.split(',');
      if (parts.length > 1) {
        newRecipe[`strMeasure${index + 1}`] = parts[0].trim();
        newRecipe[`strIngredient${index + 1}`] = parts[1].trim();
      } else {
        newRecipe[`strIngredient${index + 1}`] = line.trim();
        newRecipe[`strMeasure${index + 1}`] = "";
      }
    });

    const userRecipes = JSON.parse(localStorage.getItem('userRecipes') || '[]');
    userRecipes.push(newRecipe);
    localStorage.setItem('userRecipes', JSON.stringify(userRecipes));

    toast({
      title: "Recipe Added Successfully",
      description: "Your new recipe has been added to your collection!",
    });

    navigate('/recipes');
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 mb-8">
            <BackButton />
            <h1 className="text-4xl font-bold text-white">Add New Recipe</h1>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Recipe Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter recipe title" 
                          className="bg-gray-800 border-gray-700 text-white" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Category</FormLabel>
                      <FormControl>
                        <select 
                          className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm text-white ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          {...field}
                        >
                          <option value="breakfast">Breakfast</option>
                          <option value="lunch">Lunch</option>
                          <option value="dinner">Dinner</option>
                          <option value="desserts">Desserts</option>
                        </select>
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />

                <div>
                  <Label htmlFor="image" className="text-white">Recipe Image</Label>
                  <div className="mt-2">
                    <div className="flex items-center justify-center w-full">
                      <label
                        htmlFor="image-upload"
                        className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-700 border-dashed rounded-lg cursor-pointer bg-gray-800 hover:bg-gray-700 transition-colors"
                      >
                        {image ? (
                          <img
                            src={image}
                            alt="Recipe preview"
                            className="w-full h-full object-cover rounded-lg"
                          />
                        ) : (
                          <div className="flex flex-col items-center justify-center pt-5 pb-6">
                            <ImagePlus className="w-12 h-12 text-gray-400 mb-4" />
                            <p className="mb-2 text-sm text-gray-400">
                              <span className="font-semibold">Click to upload</span> or drag and drop
                            </p>
                            <p className="text-xs text-gray-500">PNG, JPG or GIF (MAX. 800x400px)</p>
                          </div>
                        )}
                        <input
                          id="image-upload"
                          type="file"
                          className="hidden"
                          accept="image/*"
                          onChange={handleImageChange}
                        />
                      </label>
                    </div>
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter recipe description"
                          className="bg-gray-800 border-gray-700 text-white min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="ingredients"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Ingredients</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter ingredients (one per line, or 'quantity, ingredient')"
                          className="bg-gray-800 border-gray-700 text-white min-h-[150px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="instructions"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Instructions</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter cooking instructions step by step"
                          className="bg-gray-800 border-gray-700 text-white min-h-[200px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />

                <div className="flex gap-4">
                  <FormField
                    control={form.control}
                    name="cookTime"
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormLabel className="text-white">Cooking Time (minutes)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="30"
                            className="bg-gray-800 border-gray-700 text-white"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="servings"
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormLabel className="text-white">Servings</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="4"
                            className="bg-gray-800 border-gray-700 text-white"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full">
                Add Recipe
              </Button>
            </form>
          </Form>
        </div>
      </main>
    </div>
  );
};

export default AddRecipe;
