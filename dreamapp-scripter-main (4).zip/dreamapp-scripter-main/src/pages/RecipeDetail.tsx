
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { mealApi } from "@/services/mealApi";
import { Card } from "@/components/ui/card";
import { Nav } from "@/components/Nav";
import { RecipeHeader } from "@/components/recipe/RecipeHeader";
import { RecipeImageSection } from "@/components/recipe/RecipeImageSection";
import { RecipeInfoSection } from "@/components/recipe/RecipeInfoSection";
import { RecipeContent } from "@/components/recipe/RecipeContent";
import { RecentlyViewedHandler } from "@/components/recipe/RecentlyViewedHandler";
import { RecipeLoading } from "@/components/recipe/RecipeLoading";
import { RecipeNotFound } from "@/components/recipe/RecipeNotFound";
import { getIngredients, toggleRecipeFavorite } from "@/utils/recipeUtils";
import { toast } from "@/hooks/use-toast";
import { Advertisement } from "@/components/Advertisement";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const RecipeDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [isFavorite, setIsFavorite] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRecipe, setUserRecipe] = useState<any>(null);
  const navigate = useNavigate();

  // For recipe-specific ads - dynamically set based on recipe
  const [customAdUrl, setCustomAdUrl] = useState<string | undefined>(undefined);
  const [customAdTitle, setCustomAdTitle] = useState<string | undefined>(undefined);

  // Check if this is a user-created recipe
  useEffect(() => {
    if (id && id.startsWith('user-recipe-')) {
      const userRecipes = JSON.parse(localStorage.getItem('userRecipes') || '[]');
      const foundRecipe = userRecipes.find((recipe: any) => recipe.idMeal === id);
      if (foundRecipe) {
        setUserRecipe(foundRecipe);
      }
    }
  }, [id]);

  const { data: recipe, isLoading } = useQuery({
    queryKey: ["recipe", id],
    queryFn: () => mealApi.getMealById(id!),
    enabled: !!id && !id.startsWith('user-recipe-'),
  });

  useEffect(() => {
    // Check subscription and login status
    const checkStatus = () => {
      const subscriptionStatus = localStorage.getItem("isSubscribed");
      setIsSubscribed(subscriptionStatus === "true");
      
      const loginStatus = localStorage.getItem("isLoggedIn");
      setIsLoggedIn(loginStatus === "true");
    };
    
    // Check immediately and set up regular checking
    checkStatus();
    
    // Listen for changes in status
    window.addEventListener("storage", checkStatus);
    
    // Check favorites status
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    if (savedFavorites && id) {
      const favorites = JSON.parse(savedFavorites);
      const isInFavorites = favorites.some((fav: any) => fav.idMeal === id);
      setIsFavorite(isInFavorites);
    }
    
    // Set up recipe-specific ad if we have recipe data
    const currentRecipe = userRecipe || recipe;
    if (currentRecipe) {
      // Use recipe attributes to customize the ad
      // For example, if it's an Italian recipe, show Italian cooking equipment
      const category = currentRecipe.strCategory?.toLowerCase();
      if (category?.includes('chicken')) {
        setCustomAdTitle("Premium Kitchen Knives - Perfect for Chicken Recipes");
      } else if (category?.includes('seafood')) {
        setCustomAdTitle("Professional Seafood Cooking Set - Limited Time Offer");
      } else if (category?.includes('dessert')) {
        setCustomAdTitle("Baking Equipment Sale - Perfect Your Desserts");
      }
    }
    
    return () => {
      window.removeEventListener("storage", checkStatus);
    };
  }, [id, recipe, userRecipe]);

  const handleToggleFavorite = () => {
    const currentRecipe = userRecipe || recipe;
    if (!currentRecipe) return;
    
    if (isFavorite) {
      // Remove from favorites
      toggleRecipeFavorite(currentRecipe, isFavorite, setIsFavorite);
      toast({
        title: "Removed from favorites",
        description: `${currentRecipe.strMeal} has been removed from your favorites`,
      });
    } else {
      // Add to favorites
      toggleRecipeFavorite(currentRecipe, isFavorite, setIsFavorite);
      toast({
        title: "Added to favorites",
        description: `${currentRecipe.strMeal} has been added to your favorites`,
      });
    }
  };

  const handleDeleteUserRecipe = () => {
    if (!userRecipe || !id) return;

    // Confirm deletion
    if (window.confirm("Are you sure you want to delete this recipe?")) {
      // Get current user recipes
      const userRecipes = JSON.parse(localStorage.getItem('userRecipes') || '[]');
      // Filter out the one to delete
      const updatedRecipes = userRecipes.filter((recipe: any) => recipe.idMeal !== id);
      // Save back to localStorage
      localStorage.setItem('userRecipes', JSON.stringify(updatedRecipes));
      
      // Remove from favorites if it's there
      const savedFavorites = localStorage.getItem('favoriteRecipes');
      if (savedFavorites) {
        const favorites = JSON.parse(savedFavorites);
        const updatedFavorites = favorites.filter((fav: any) => fav.idMeal !== id);
        localStorage.setItem('favoriteRecipes', JSON.stringify(updatedFavorites));
      }
      
      toast({
        title: "Recipe Deleted",
        description: "Your recipe has been deleted successfully",
      });
      
      // Navigate back to recipes page
      navigate('/recipes');
    }
  };

  // Use either the user recipe or the API recipe
  const currentRecipe = userRecipe || recipe;

  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center -z-10"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2940&auto=format&fit=crop")',
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0,0,0,0.85)'
        }}
      />
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <RecipeHeader recipe={currentRecipe} id={id || ""} />
            
            {userRecipe && (
              <Button 
                variant="destructive" 
                onClick={handleDeleteUserRecipe}
                className="flex items-center gap-2"
              >
                <Trash2 className="h-4 w-4" />
                Delete Recipe
              </Button>
            )}
          </div>

          {isLoading && !userRecipe ? (
            <RecipeLoading />
          ) : currentRecipe ? (
            <>
              <RecentlyViewedHandler recipe={currentRecipe} />
              <Card className="bg-gray-800/50 border-gray-700 overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <RecipeImageSection 
                    recipe={currentRecipe} 
                    isFavorite={isFavorite} 
                    toggleFavorite={handleToggleFavorite} 
                  />
                  <RecipeInfoSection 
                    recipe={currentRecipe} 
                    isFavorite={isFavorite} 
                    toggleFavorite={handleToggleFavorite} 
                  />
                </div>
                <RecipeContent 
                  ingredients={getIngredients(currentRecipe)} 
                  instructions={
                    typeof currentRecipe.strInstructions === 'string'
                      ? currentRecipe.strInstructions.split('\r\n').filter(Boolean)
                      : [currentRecipe.strInstructions]
                  }
                />
              </Card>
            </>
          ) : (
            <RecipeNotFound />
          )}
        </div>
      </main>
      <Advertisement 
        isSubscribed={isSubscribed}
        customAdUrl={customAdUrl}
        customAdTitle={customAdTitle}
        frequentAds={!isLoggedIn}
      />
    </div>
  );
};

export default RecipeDetailPage;
