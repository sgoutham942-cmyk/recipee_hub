
import { Nav } from "@/components/Nav";
import { ChefHat, PlayCircle, BookMarked, Search } from "lucide-react";

const FeaturesPage = () => {
  const features = [
    {
      icon: <ChefHat className="w-16 h-16" />,
      title: "Expert Recipes",
      description: "Curated by Professional Chefs & Food Experts",
      benefits: [
        "Get expert-crafted recipes",
        "Learn professional techniques",
        "Discover unique flavors",
        "Access chef tips and tricks",
        "Learn cooking fundamentals"
      ]
    },
    {
      icon: <PlayCircle className="w-16 h-16" />,
      title: "Step by Step",
      description: "Easy-to-Follow Recipe Videos & Guides",
      benefits: [
        "Watch detailed recipe videos",
        "Follow clear instructions",
        "Master new cooking skills",
        "Visual cooking demonstrations",
        "Pause and rewind as needed"
      ]
    },
    {
      icon: <BookMarked className="w-16 h-16" />,
      title: "Save Favorites",
      description: "Build Your Personal Cookbook",
      benefits: [
        "Save recipes with one click",
        "Organize your collection",
        "Access anywhere",
        "Create custom collections",
        "Share with friends"
      ]
    },
    {
      icon: <Search className="w-16 h-16" />,
      title: "Smart Search",
      description: "Find Any Recipe Instantly!",
      benefits: [
        "Type in any dish name for results",
        "Filter by ingredients",
        "Search by cuisine",
        "Advanced filtering options",
        "Save search preferences"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Why Choose Recipe Hub?</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Discover the features that make Recipe Hub the perfect platform for all your cooking needs. From expert-curated content to smart search capabilities.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="p-8 rounded-lg bg-gray-800/50 backdrop-blur-sm hover:bg-gray-800/70 transition-all duration-300"
              >
                <div className="flex flex-col items-center text-center space-y-6">
                  <div className="p-6 rounded-full bg-primary/10 text-primary">
                    {feature.icon}
                  </div>
                  <h3 className="text-2xl font-semibold text-white">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                  <ul className="text-gray-400 space-y-3">
                    {feature.benefits.map((benefit) => (
                      <li key={benefit} className="flex items-center justify-center gap-2">
                        <span className="text-primary">•</span> {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default FeaturesPage;
