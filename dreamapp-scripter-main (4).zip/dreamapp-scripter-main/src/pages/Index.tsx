
import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { Categories } from "@/components/Categories";
import { Features } from "@/components/Features";
import { Advertisement } from "@/components/Advertisement";
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Index = () => {
  // In a real app, this would come from your auth system
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const cursorRef = useRef<HTMLDivElement>(null);
  
  // You can replace these with your own ad URLs and titles
  const [customAdUrl, setCustomAdUrl] = useState<string | undefined>(undefined);
  const [customAdTitle, setCustomAdTitle] = useState<string | undefined>(undefined);

  // Check if user is subscribed and logged in
  useEffect(() => {
    // More robust check for subscription status
    const checkSubscription = () => {
      const subscriptionStatus = localStorage.getItem("isSubscribed");
      setIsSubscribed(subscriptionStatus === "true");
    };
    
    // Check login status
    const checkLoginStatus = () => {
      const loginStatus = localStorage.getItem("isLoggedIn");
      setIsLoggedIn(loginStatus === "true");
      
      // If not logged in, show login prompt after 1 second
      if (loginStatus !== "true") {
        setTimeout(() => {
          setShowLoginPrompt(true);
        }, 1000);
      }
    };
    
    // Check immediately and set up regular checking
    checkSubscription();
    checkLoginStatus();
    
    // Listen for changes in status
    window.addEventListener("storage", () => {
      checkSubscription();
      checkLoginStatus();
    });
    
    // Check periodically
    const interval = setInterval(() => {
      checkSubscription();
      checkLoginStatus();
    }, 5000);
    
    return () => {
      window.removeEventListener("storage", checkSubscription);
      clearInterval(interval);
    };
  }, []);
  
  // Custom cursor effect
  useEffect(() => {
    const cursor = cursorRef.current;
    if (!cursor) return;
    
    // Only show on desktop
    if (window.innerWidth < 1024) {
      cursor.style.display = 'none';
      return;
    }
    
    cursor.style.display = 'block';
    
    const onMouseMove = (e: MouseEvent) => {
      cursor.style.left = `${e.clientX}px`;
      cursor.style.top = `${e.clientY}px`;
    };
    
    window.addEventListener('mousemove', onMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, []);

  // If not logged in, show login prompt
  if (showLoginPrompt && !isLoggedIn) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-xl animate-fade-in">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to RecipeHub</h1>
            <p className="text-gray-600">Please sign in or create an account to continue</p>
          </div>
          
          <div className="space-y-4">
            <Link to="/auth">
              <Button className="w-full py-6 text-lg" size="lg">
                Sign In
              </Button>
            </Link>
            
            <Link to="/auth">
              <Button variant="outline" className="w-full py-6 text-lg" size="lg" onClick={() => {
                // Navigate to auth page with sign up tab active
                localStorage.setItem("authAction", "signup");
              }}>
                Create Account
              </Button>
            </Link>
          </div>
          
          <p className="text-center text-gray-500 text-sm mt-8">
            Unlock exclusive recipes and features by joining our community
          </p>
        </div>
        
        {/* Ad for non-logged in users */}
        <Advertisement 
          isSubscribed={false}
          forceShow={true}
          customAdUrl={customAdUrl} 
          customAdTitle={customAdTitle}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div ref={cursorRef} className="cursor-gradient hidden lg:block"></div>
      <Nav />
      <main>
        <Hero />
        <div className="relative">
          <div 
            className="absolute inset-0 bg-cover bg-center -z-10"
            style={{ 
              backgroundImage: 'url("https://images.unsplash.com/photo-1556910103-1c02745adc6b?q=80&w=2940&auto=format&fit=crop")',
              backgroundBlendMode: 'multiply',
              backgroundColor: 'rgba(0,0,0,0.85)'
            }}
          />
          <Categories />
          <Features />
        </div>
      </main>
      <Advertisement 
        isSubscribed={isSubscribed} 
        customAdUrl={customAdUrl} 
        customAdTitle={customAdTitle}
        frequentAds={!isLoggedIn}
      />
    </div>
  );
};

export default Index;
