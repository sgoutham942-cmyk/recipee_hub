import { Nav } from "@/components/Nav";
import { ChefHat } from "lucide-react";
import { BackButton } from "@/components/BackButton";

const AboutPage = () => {
  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center -z-10"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1556911220-e15b29be8c8f?q=80&w=2940&auto=format&fit=crop")',
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0,0,0,0.85)'
        }}
      />
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <BackButton />
          </div>
          <div className="text-center mb-12">
            <ChefHat className="w-16 h-16 text-primary mx-auto mb-6" />
            <h1 className="text-4xl font-bold text-white mb-4">About Recipe Hub</h1>
            <p className="text-gray-400 text-lg">
              Your ultimate destination for culinary inspiration and cooking excellence
            </p>
          </div>

          <div className="prose prose-invert mx-auto">
            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              Recipe Hub was created with a simple mission: to make cooking accessible, enjoyable, and inspiring for everyone. Whether you're a beginner cook or a seasoned chef, our platform provides the tools and resources you need to create amazing dishes.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-12">
              <div className="bg-gray-800/50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-white mb-4">Our Mission</h3>
                <p className="text-gray-400">
                  To inspire and empower people to cook delicious, healthy meals at home by providing easy-to-follow recipes and expert cooking tips.
                </p>
              </div>

              <div className="bg-gray-800/50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-white mb-4">Our Vision</h3>
                <p className="text-gray-400">
                  To create a global community of food lovers sharing their passion for cooking and discovering new culinary experiences.
                </p>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-white mb-4">What Sets Us Apart</h2>
            <ul className="space-y-4 text-gray-300">
              <li>• Expert-curated recipes from professional chefs</li>
              <li>• Step-by-step instructions with photos</li>
              <li>• Active community of food enthusiasts</li>
              <li>• Regular updates with new recipes</li>
              <li>• Focus on both traditional and modern cuisine</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AboutPage;
