
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { mealApi } from "@/services/mealApi";
import { Nav } from "@/components/Nav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Clock, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { BackButton } from "@/components/BackButton";
import { Skeleton } from "@/components/ui/skeleton";
import { useState, useEffect } from "react";
import { toast } from "@/hooks/use-toast";

const CategoryPage = () => {
  const { category } = useParams<{ category: string }>();
  const [favorites, setFavorites] = useState<Record<string, boolean>>({});

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    if (savedFavorites) {
      const favoritesArray = JSON.parse(savedFavorites);
      const favoritesMap: Record<string, boolean> = {};
      favoritesArray.forEach((fav: any) => {
        favoritesMap[fav.idMeal] = true;
      });
      setFavorites(favoritesMap);
    }
  }, []);

  // Map our custom categories to TheMealDB API categories
  const getCategoryForApi = (customCategory: string | undefined): string => {
    const categoryMap: Record<string, string> = {
      'breakfast': 'Breakfast',
      'lunch': 'Miscellaneous', // TheMealDB doesn't have a specific "Lunch" category
      'dinner': 'Dinner',       // Using custom mapping
      'desserts': 'Dessert'
    };
    
    return categoryMap[customCategory?.toLowerCase() || ''] || (customCategory || '');
  };

  const apiCategory = getCategoryForApi(category);

  const { data: recipes, isLoading } = useQuery({
    queryKey: ["recipesByCategory", apiCategory],
    queryFn: () => mealApi.getMealsByCategory(apiCategory),
    enabled: !!apiCategory,
  });

  const toggleFavorite = (recipe: any, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Get current favorites from localStorage
    const savedFavorites = localStorage.getItem('favoriteRecipes');
    let favoritesArray = savedFavorites ? JSON.parse(savedFavorites) : [];
    
    if (favorites[recipe.idMeal]) {
      // Remove from favorites
      favoritesArray = favoritesArray.filter((fav: any) => fav.idMeal !== recipe.idMeal);
      toast({
        title: "Removed from favorites",
        description: `${recipe.strMeal} has been removed from your favorites`,
      });
    } else {
      // Add to favorites
      const recipeToSave = {
        idMeal: recipe.idMeal,
        strMeal: recipe.strMeal,
        strMealThumb: recipe.strMealThumb,
        strCategory: recipe.strCategory
      };
      favoritesArray.push(recipeToSave);
      toast({
        title: "Added to favorites",
        description: `${recipe.strMeal} has been added to your favorites`,
      });
    }
    
    // Save back to localStorage
    localStorage.setItem('favoriteRecipes', JSON.stringify(favoritesArray));
    
    // Update the UI
    setFavorites(prev => ({
      ...prev,
      [recipe.idMeal]: !prev[recipe.idMeal]
    }));
  };

  const getCategoryIcon = () => {
    const categoryIcons: Record<string, JSX.Element> = {
      breakfast: <span className="text-2xl">🍳</span>,
      lunch: <span className="text-2xl">🍲</span>,
      dinner: <span className="text-2xl">🍽️</span>,
      desserts: <span className="text-2xl">🍰</span>,
      dessert: <span className="text-2xl">🍰</span>,
      chicken: <span className="text-2xl">🍗</span>,
      pasta: <span className="text-2xl">🍝</span>,
      seafood: <span className="text-2xl">🦞</span>,
      vegetarian: <span className="text-2xl">🥗</span>,
    };
    
    const key = category?.toLowerCase() || "";
    return categoryIcons[key] || <span className="text-2xl">📋</span>;
  };

  // Display a formatted category name
  const getCategoryDisplayName = () => {
    if (!category) return '';
    return category.charAt(0).toUpperCase() + category.slice(1);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <Nav />
      <main className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <BackButton />
              <h1 className="text-3xl md:text-4xl font-bold text-white flex items-center gap-3">
                {getCategoryIcon()}
                {getCategoryDisplayName()} Recipes
              </h1>
            </div>
            <div>
              <Link to="/categories">
                <Button variant="outline">All Categories</Button>
              </Link>
            </div>
          </div>

          {isLoading ? (
            // Loading skeletons
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array(9).fill(0).map((_, index) => (
                <Card key={index} className="bg-gray-800/50 border-gray-700">
                  <div className="space-y-4">
                    <Skeleton className="h-48 w-full rounded-t-lg" />
                    <div className="p-4">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/4 mb-4" />
                      <div className="flex justify-between">
                        <Skeleton className="h-4 w-1/3" />
                        <Skeleton className="h-4 w-1/3" />
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : recipes && recipes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {recipes.map((recipe: any) => (
                <Card key={recipe.idMeal} className="bg-gray-800/50 border-gray-700 overflow-hidden group">
                  <Link to={`/recipe/${recipe.idMeal}`}>
                    <div className="relative aspect-video overflow-hidden rounded-t-lg">
                      <img
                        src={recipe.strMealThumb}
                        alt={recipe.strMeal}
                        className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-semibold text-white group-hover:text-primary transition-colors duration-200">{recipe.strMeal}</h3>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className={`${favorites[recipe.idMeal] ? 'text-red-500' : 'text-gray-400'} hover:text-red-400`}
                          onClick={(e) => toggleFavorite(recipe, e)}
                        >
                          <Heart className="h-5 w-5" fill={favorites[recipe.idMeal] ? "currentColor" : "none"} />
                        </Button>
                      </div>
                      <div className="flex items-center gap-4 text-gray-400 text-sm mt-4">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          30 mins
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          4 servings
                        </div>
                      </div>
                    </div>
                  </Link>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h2 className="text-2xl font-semibold text-white mb-2">No recipes found</h2>
              <p className="text-gray-300 mb-6">We couldn't find any recipes in this category.</p>
              <Link to="/recipes">
                <Button>Browse all recipes</Button>
              </Link>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default CategoryPage;
