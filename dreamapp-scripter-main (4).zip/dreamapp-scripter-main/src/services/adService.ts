
// This service fetches ads from a real API
// For a production app, you would replace this with your actual ad network integration

interface Ad {
  id: string;
  url: string;
  title: string;
  duration: number; // in seconds
  audioUrl?: string;
  isYoutubeVideo?: boolean;
}

// Using a free video API for demonstration purposes
const fetchAdsFromApi = async (): Promise<Ad[]> => {
  try {
    // Custom YouTube ads that the user requested
    const youtubeAds = [
      {
        id: 'youtube-ad-1',
        url: 'https://youtube.com/shorts/4OhXi52NcXs?si=aDLJB__9iJVC6Wv2',
        title: 'Special YouTube Short - Featured Ad',
        duration: 15,
        isYoutubeVideo: true
      },
      {
        id: 'youtube-ad-2',
        url: 'https://youtube.com/shorts/P4VkiJbISCE?si=iqSC_VBOx3hHb6O7',
        title: 'Quick Breakfast Recipe - Easy Cooking Tip',
        duration: 15,
        isYoutubeVideo: true
      }
    ];
    
    try {
      // In a real app, this would be your ad network API endpoint
      const response = await fetch('https://random-data-api.com/api/v2/appliances?size=5');
      
      if (!response.ok) {
        throw new Error(`API returned status ${response.status}`);
      }
      
      const data = await response.json();
      
      // Transform the random data into our ad format
      // In a real integration, the ad network would provide properly structured data
      const apiAds = data.map((item: any, index: number) => {
        // Create varied durations between 5-15 seconds
        const duration = Math.floor(Math.random() * 11) + 5;
        
        // Use free videos from Pixabay as our ad content
        const videoOptions = [
          'https://cdn.pixabay.com/vimeo/149196310/blender-2635.mp4?width=640&hash=32b777c6df045bfab0a1572374d57d731e61308c',
          'https://cdn.pixabay.com/vimeo/190499502/food-4854.mp4?width=640&hash=c5a3d0fa4f77fc720d73557bb16b03479c0fed12',
          'https://cdn.pixabay.com/vimeo/414364523/baking-30208.mp4?width=640&hash=28d5a46ba8c0e61db9be1764578c07d41fdff0b5',
          'https://cdn.pixabay.com/vimeo/328377357/cooking-18554.mp4?width=640&hash=1b8e1bcb039ad2b5ca2175b31ea9d66a8b8c6cda',
          'https://cdn.pixabay.com/vimeo/348748541/tomatoes-22087.mp4?width=640&hash=6d7ab2f5c9c7fa2cf8e9aa7d5e2185e1d61bed9e'
        ];
        
        // Use free audio tracks for ad sounds
        const audioOptions = [
          'https://cdn.pixabay.com/audio/2021/11/25/audio_cb4f1f8b9e.mp3',
          'https://cdn.pixabay.com/audio/2022/01/18/audio_d0c6ff1efd.mp3',
          'https://cdn.pixabay.com/audio/2022/03/15/audio_c8b8e10732.mp3',
          'https://cdn.pixabay.com/audio/2021/04/07/audio_cb1e132efd.mp3'
        ];
        
        return {
          id: item.id || `ad-${index}`,
          url: videoOptions[index % videoOptions.length],
          title: `${item.brand} ${item.equipment} - Special Offer!`,
          duration: duration,
          audioUrl: audioOptions[index % audioOptions.length]
        };
      });
      
      // Add the YouTube ads as the first items in the array
      return [...youtubeAds, ...apiAds];
      
    } catch (error) {
      console.error('Error fetching ads from API:', error);
      // If API fails, at least return the YouTube ads and fallbacks
      return [
        ...youtubeAds,
        {
          id: 'fallback-1',
          url: 'https://cdn.pixabay.com/vimeo/149196310/blender-2635.mp4?width=640&hash=32b777c6df045bfab0a1572374d57d731e61308c',
          title: 'Premium Kitchen Blender - Special Offer',
          duration: 10,
          audioUrl: 'https://cdn.pixabay.com/audio/2021/11/25/audio_cb4f1f8b9e.mp3'
        },
        {
          id: 'fallback-2',
          url: 'https://cdn.pixabay.com/vimeo/190499502/food-4854.mp4?width=640&hash=c5a3d0fa4f77fc720d73557bb16b03479c0fed12',
          title: 'Gourmet Cooking Ingredients - Shop Now',
          duration: 8,
          audioUrl: 'https://cdn.pixabay.com/audio/2022/01/18/audio_d0c6ff1efd.mp3'
        }
      ];
    }
  } catch (error) {
    console.error('Error fetching ads:', error);
    // Fallback ads in case of any other errors
    return [
      {
        id: 'fallback-1',
        url: 'https://cdn.pixabay.com/vimeo/149196310/blender-2635.mp4?width=640&hash=32b777c6df045bfab0a1572374d57d731e61308c',
        title: 'Premium Kitchen Blender - Special Offer',
        duration: 10,
        audioUrl: 'https://cdn.pixabay.com/audio/2021/11/25/audio_cb4f1f8b9e.mp3'
      },
      {
        id: 'fallback-2',
        url: 'https://cdn.pixabay.com/vimeo/190499502/food-4854.mp4?width=640&hash=c5a3d0fa4f77fc720d73557bb16b03479c0fed12',
        title: 'Gourmet Cooking Ingredients - Shop Now',
        duration: 8,
        audioUrl: 'https://cdn.pixabay.com/audio/2022/01/18/audio_d0c6ff1efd.mp3'
      }
    ];
  }
};

export { fetchAdsFromApi };
export type { Ad };
